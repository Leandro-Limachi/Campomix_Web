
from decimal import Decimal, InvalidOperation
from functools import wraps

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
    abort,
    jsonify
)

from mysql.connector import Error as MySQLError
from app.models.orden_produccion_model import OrdenProduccionModel
from app.models.disponibilidad_mp_model import DisponibilidadMPModel
from app.models.produccion_model import ProduccionModel
from app.utils import a_decimal
from datetime import datetime, date, timedelta


orden_produccion_bp = Blueprint(
    "ordenes_produccion",
    __name__,
    url_prefix="/ordenes-produccion"
)


# ==========================================
# VERIFICAR SESIÓN
# ==========================================

def login_requerido(funcion):

    @wraps(funcion)
    def decorador(*args, **kwargs):

        if "usuario_id" not in session:
            return redirect(url_for("auth.login"))

        return funcion(*args, **kwargs)

    return decorador


# ==========================================
# VALIDAR CANTIDAD
# ==========================================

def validar_cantidad(valor):

    try:
        cantidad = Decimal(str(valor).strip())

        if not cantidad.is_finite():
            raise ValueError()

        if cantidad <= 0:
            raise ValueError()

        if cantidad > Decimal("999999999999999.999"):
            raise ValueError()

        if cantidad.as_tuple().exponent < -3:
            raise ValueError()

        return cantidad

    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(
            "La cantidad debe ser mayor que cero "
            "y tener máximo 3 decimales."
        )


# ==========================================
# LISTAR ÓRDENES
# ==========================================

@orden_produccion_bp.route("/")
@login_requerido
def listar():

    ordenes = OrdenProduccionModel.listar()
    resumen = ProduccionModel.resumen_estados()

    return render_template(
        "ordenes_produccion/listar.html",
        ordenes=ordenes,
        resumen=resumen
    )


# ==========================================
# NUEVA ORDEN
# ==========================================

@orden_produccion_bp.route(
    "/nueva",
    methods=["GET", "POST"]
)
@login_requerido
def nueva():

    recetas = OrdenProduccionModel.listar_recetas_vigentes()

    if request.method == "POST":

        try:
            id_receta = int(
                request.form.get("id_receta", "")
            )

            cantidad = validar_cantidad(
                request.form.get("cantidad_planificada", "")
            )

            observacion = request.form.get(
                "observacion", ""
            ).strip()

            if id_receta <= 0:
                raise ValueError(
                    "Debe seleccionar una receta válida."
                )

            id_usuario = session["usuario_id"]

            id_orden = OrdenProduccionModel.crear(
                id_receta=id_receta,
                cantidad_planificada=cantidad,
                id_usuario=id_usuario,
                observacion=observacion
            )

            flash(
                "Orden de producción registrada correctamente.",
                "success"
            )

            return redirect(
                url_for(
                    "ordenes_produccion.detalle",
                    id_orden=id_orden
                )
            )

        except (ValueError, TypeError) as error:

            flash(
                str(error) if str(error)
                else "Verifique los datos ingresados.",
                "danger"
            )

        except MySQLError:

            flash(
                "No se pudo registrar la orden. "
                "Verifique la información e inténtelo nuevamente.",
                "danger"
            )

    return render_template(
        "ordenes_produccion/formulario.html",
        recetas=recetas
    )


# ==========================================
# CONSULTAR INGREDIENTES DE UNA RECETA
# ==========================================


@orden_produccion_bp.route(
    "/calcular",
    methods=["POST"]
)
@login_requerido
def calcular():

    datos = request.get_json(silent=True) or {}

    try:
        id_receta = int(datos.get("id_receta", 0))

        cantidad = validar_cantidad(
            datos.get("cantidad_planificada", "")
        )

        if id_receta <= 0:
            raise ValueError(
                "Seleccione una receta válida."
            )

        receta = OrdenProduccionModel.obtener_receta(
            id_receta
        )

        if not receta or receta["estado"] != "VIGENTE":
            raise ValueError(
                "Solo se pueden utilizar recetas vigentes."
            )

        # Calcular cantidades y comprobar inventario
        resultado = DisponibilidadMPModel.verificar_receta(
            id_receta,
            cantidad
        )

        ingredientes = []

        for item in resultado["ingredientes"]:

            ingredientes.append({
                "id_materia": item["id_materia"],
                "codigo": item["codigo"],
                "materia_prima": item["materia_prima"],
                "unidad": item["unidad"],
                "cantidad_necesaria": str(
                    item["cantidad_necesaria"]
                ),
                "stock_disponible": str(
                    item["stock_disponible"]
                ),
                "faltante": str(item["faltante"]),
                "suficiente": item["suficiente"]
            })

        return jsonify({
            "ok": True,
            "producto": receta["producto"],
            "unidad_producto": receta["unidad"],
            "cantidad_planificada": str(cantidad),
            "cantidad_base": str(receta["cantidad_base"]),
            "produccion_posible": resultado["produccion_posible"],
            "ingredientes": ingredientes
        })

    except (ValueError, TypeError) as error:

        return jsonify({
            "ok": False,
            "mensaje": str(error)
        }), 400

    except MySQLError:

        return jsonify({
            "ok": False,
            "mensaje": "Error al consultar el inventario."
        }), 500


# ==========================================
# DETALLE DE UNA ORDEN
# ==========================================

@orden_produccion_bp.route(
    "/<int:id_orden>"
)
@login_requerido
def detalle(id_orden):

    orden = OrdenProduccionModel.obtener(id_orden)

    if orden is None:
        abort(404)

    calculo = OrdenProduccionModel.calcular_ingredientes(
        orden["id_receta"],
        orden["cantidad_planificada"]
    )

    disponibilidad = None
    if orden["estado"] == "PLANIFICADA":
        disponibilidad = DisponibilidadMPModel.verificar_receta(
            orden["id_receta"],
            orden["cantidad_planificada"]
        )

    vida_util = OrdenProduccionModel.vida_util_producto(id_orden)
    vencimiento_sugerido = date.today() + timedelta(days=vida_util or 30)

    return render_template(
        "ordenes_produccion/detalle.html",
        orden=orden,
        calculo=calculo,
        disponibilidad=disponibilidad,
        consumos=ProduccionModel.consumos(id_orden),
        lotes=ProduccionModel.lotes_generados(id_orden),
        vencimiento_sugerido=vencimiento_sugerido
    )


# ==========================================
# INICIAR PRODUCCIÓN (consume MP)
# ==========================================

@orden_produccion_bp.route("/<int:id_orden>/iniciar", methods=["POST"])
@login_requerido
def iniciar(id_orden):
    try:
        ProduccionModel.iniciar(id_orden, session["usuario_id"])
        flash(
            "Producción iniciada. Las materias primas fueron "
            "descontadas del inventario (FEFO).",
            "success"
        )
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo iniciar la producción.", "danger")

    return redirect(url_for("ordenes_produccion.detalle", id_orden=id_orden))


# ==========================================
# FINALIZAR PRODUCCIÓN (genera lote PT)
# ==========================================

@orden_produccion_bp.route("/<int:id_orden>/finalizar", methods=["POST"])
@login_requerido
def finalizar(id_orden):
    try:
        cantidad = a_decimal(
            request.form.get("cantidad_obtenida", ""),
            "La cantidad obtenida"
        )

        texto_fecha = request.form.get("fecha_vencimiento", "").strip()
        fecha_venc = None
        if texto_fecha:
            try:
                fecha_venc = datetime.strptime(texto_fecha, "%Y-%m-%d").date()
            except ValueError:
                raise ValueError("La fecha de vencimiento no es válida.")

        observacion = request.form.get("observacion", "").strip()[:255]

        ProduccionModel.finalizar(
            id_orden, cantidad, fecha_venc,
            session["usuario_id"], observacion
        )
        flash(
            "Producción finalizada. Se generó el lote de producto "
            "terminado en CUARENTENA para control de calidad.",
            "success"
        )
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo finalizar la producción.", "danger")

    return redirect(url_for("ordenes_produccion.detalle", id_orden=id_orden))


# ==========================================
# CANCELAR ORDEN
# ==========================================

@orden_produccion_bp.route("/<int:id_orden>/cancelar", methods=["POST"])
@login_requerido
def cancelar(id_orden):
    motivo = request.form.get("motivo", "").strip()[:200]
    try:
        if not motivo:
            raise ValueError("Indique el motivo de la cancelación.")
        ProduccionModel.cancelar(id_orden, session["usuario_id"], motivo)
        flash("La orden fue cancelada.", "warning")
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo cancelar la orden.", "danger")

    return redirect(url_for("ordenes_produccion.detalle", id_orden=id_orden))
