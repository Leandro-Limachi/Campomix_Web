from datetime import datetime

from flask import (
    Blueprint, render_template, request,
    redirect, url_for, flash, session, abort
)
from mysql.connector import Error as MySQLError

from app.models.producto_terminado_model import ProductoTerminadoModel
from app.utils import login_requerido, a_decimal


producto_terminado_bp = Blueprint(
    "productos_terminados",
    __name__,
    url_prefix="/productos-terminados"
)


def _fecha(texto):
    if not texto:
        return None
    try:
        return datetime.strptime(texto, "%Y-%m-%d").date()
    except ValueError:
        return None


# ==========================================
# INVENTARIO PT
# ==========================================

@producto_terminado_bp.route("/")
@login_requerido
def inventario():
    busqueda = request.args.get("buscar", "").strip()
    id_categoria = request.args.get("categoria", type=int)

    productos = ProductoTerminadoModel.inventario(busqueda, id_categoria)
    resumen = ProductoTerminadoModel.resumen()
    estados = ProductoTerminadoModel.contar_lotes_por_estado()

    return render_template(
        "productos_terminados/inventario.html",
        productos=productos,
        resumen=resumen,
        estados=estados,
        categorias=ProductoTerminadoModel.listar_categorias(),
        busqueda=busqueda,
        id_categoria=id_categoria
    )


@producto_terminado_bp.route(
    "/stock-minimo/<int:id_producto>", methods=["POST"]
)
@login_requerido
def stock_minimo(id_producto):
    try:
        valor = a_decimal(request.form.get("stock_minimo", ""),
                          "El stock mínimo")
        ProductoTerminadoModel.actualizar_stock_minimo(id_producto, valor)
        flash("Stock mínimo actualizado.", "success")
    except ValueError as error:
        flash(str(error), "danger")
    return redirect(url_for("productos_terminados.inventario"))


# ==========================================
# LOTES PT Y CONTROL DE CALIDAD
# ==========================================

@producto_terminado_bp.route("/lotes")
@login_requerido
def lotes():
    estado = request.args.get("estado", "").strip().upper()
    busqueda = request.args.get("buscar", "").strip()
    id_producto = request.args.get("producto", type=int)
    con_stock = request.args.get("con_stock") == "1"

    return render_template(
        "productos_terminados/lotes.html",
        lotes=ProductoTerminadoModel.lotes(
            estado, busqueda, id_producto, con_stock),
        estados=ProductoTerminadoModel.contar_lotes_por_estado(),
        productos=ProductoTerminadoModel.listar_productos(),
        estado=estado,
        busqueda=busqueda,
        id_producto=id_producto,
        con_stock=con_stock
    )


@producto_terminado_bp.route("/lotes/<int:id_lote>")
@login_requerido
def lote_detalle(id_lote):
    lote = ProductoTerminadoModel.obtener_lote(id_lote)
    if not lote:
        abort(404)
    return render_template(
        "productos_terminados/lote_detalle.html",
        lote=lote,
        movimientos=ProductoTerminadoModel.kardex(id_lote=id_lote)
    )


@producto_terminado_bp.route(
    "/lotes/<int:id_lote>/calidad", methods=["POST"]
)
@login_requerido
def cambiar_calidad(id_lote):
    estado = request.form.get("estado", "").strip().upper()
    observacion = request.form.get("observacion", "").strip()[:200]
    try:
        ProductoTerminadoModel.cambiar_calidad(
            id_lote, estado, session["usuario_id"], observacion)
        mensajes = {
            "LIBERADO": "Lote LIBERADO: ya está disponible para la venta.",
            "BLOQUEADO": "Lote BLOQUEADO: no podrá venderse.",
            "CUARENTENA": "Lote devuelto a CUARENTENA."
        }
        flash(mensajes.get(estado, "Estado actualizado."), "success")
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo actualizar el estado del lote.", "danger")

    destino = request.form.get("volver")
    if destino == "detalle":
        return redirect(url_for("productos_terminados.lote_detalle",
                                id_lote=id_lote))
    return redirect(request.referrer
                    or url_for("productos_terminados.lotes"))


@producto_terminado_bp.route(
    "/lotes/<int:id_lote>/ajuste", methods=["POST"]
)
@login_requerido
def ajuste(id_lote):
    try:
        cantidad = a_decimal(request.form.get("cantidad", ""),
                             "La cantidad", permitir_cero=False)
        ProductoTerminadoModel.registrar_ajuste(
            id_lote,
            request.form.get("tipo", ""),
            cantidad,
            session["usuario_id"],
            request.form.get("observacion", "").strip()
        )
        flash("Movimiento de inventario registrado.", "success")
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo registrar el movimiento.", "danger")

    return redirect(url_for("productos_terminados.lote_detalle",
                            id_lote=id_lote))


# ==========================================
# KARDEX
# ==========================================

@producto_terminado_bp.route("/kardex")
@login_requerido
def kardex():
    id_producto = request.args.get("producto", type=int)
    tipo = request.args.get("tipo", "").strip().upper()
    desde = _fecha(request.args.get("desde", ""))
    hasta = _fecha(request.args.get("hasta", ""))

    movimientos = ProductoTerminadoModel.kardex(
        id_producto=id_producto, tipo=tipo, desde=desde, hasta=hasta)

    entradas = sum(m["cantidad_firmada"] for m in movimientos
                   if m["cantidad_firmada"] > 0)
    salidas = -sum(m["cantidad_firmada"] for m in movimientos
                   if m["cantidad_firmada"] < 0)

    return render_template(
        "productos_terminados/kardex.html",
        movimientos=movimientos,
        productos=ProductoTerminadoModel.listar_productos(),
        id_producto=id_producto,
        tipo=tipo,
        desde=desde,
        hasta=hasta,
        entradas=entradas,
        salidas=salidas
    )
