from datetime import datetime
from decimal import Decimal

from flask import (
    Blueprint, render_template, request,
    redirect, url_for, flash, session, abort
)
from mysql.connector import Error as MySQLError

from app.models.venta_model import VentaModel, METODOS_PAGO
from app.models.cliente_model import ClienteModel
from app.utils import login_requerido, a_decimal, q2


venta_bp = Blueprint("ventas", __name__, url_prefix="/ventas")


def _fecha(texto):
    try:
        return datetime.strptime(texto, "%Y-%m-%d").date() if texto else None
    except ValueError:
        return None


def leer_items():
    """Lee las líneas de la venta enviadas por el formulario."""
    productos = request.form.getlist("id_producto[]")
    cantidades = request.form.getlist("cantidad[]")
    precios = request.form.getlist("precio[]")
    descuentos = request.form.getlist("descuento[]")

    items = []
    for i, id_producto in enumerate(productos):
        if not id_producto:
            continue
        n = i + 1
        try:
            id_producto = int(id_producto)
        except ValueError:
            raise ValueError(f"Línea {n}: producto no válido.")
        cantidad = a_decimal(cantidades[i] if i < len(cantidades) else "",
                             f"Línea {n}: la cantidad", permitir_cero=False)
        precio = a_decimal(precios[i] if i < len(precios) else "",
                           f"Línea {n}: el precio", decimales=2)
        texto_desc = descuentos[i] if i < len(descuentos) else ""
        descuento = a_decimal(texto_desc or "0",
                              f"Línea {n}: el descuento", decimales=2)
        items.append({
            "id_producto": id_producto,
            "cantidad": cantidad,
            "precio_unitario": precio,
            "descuento": q2(descuento)
        })
    return items


# ==========================================
# LISTAR
# ==========================================

@venta_bp.route("/")
@login_requerido
def listar():
    filtros = {
        "busqueda": request.args.get("buscar", "").strip(),
        "estado": request.args.get("estado", "").strip().upper(),
        "pago": request.args.get("pago", "").strip().upper(),
        "desde": _fecha(request.args.get("desde", "")),
        "hasta": _fecha(request.args.get("hasta", "")),
    }
    ventas = VentaModel.listar(
        filtros["busqueda"], filtros["estado"],
        filtros["desde"], filtros["hasta"], pago=filtros["pago"])

    total_filtrado = sum((v["total"] for v in ventas
                          if v["estado"] != "CANCELADA"), Decimal("0"))
    return render_template(
        "ventas/listar.html",
        ventas=ventas,
        resumen=VentaModel.resumen(),
        filtros=filtros,
        total_filtrado=total_filtrado
    )


# ==========================================
# NUEVA / EDITAR
# ==========================================

def _a_float(valor):
    try:
        return float(str(valor).replace(",", "."))
    except (TypeError, ValueError):
        return 0.0


def _render_formulario(venta=None, items=None, id_cliente=None):
    productos = VentaModel.productos_para_venta()
    catalogo = [{
        "id": p["id_producto"], "codigo": p["codigo"], "nombre": p["nombre"],
        "categoria": p["categoria"], "unidad": p["unidad"],
        "precio": float(p["precio_referencia"]),
        "disponible": float(p["disponible"])
    } for p in productos]

    lineas = []
    for it in items or []:
        try:
            pid = int(it["id_producto"])
        except (TypeError, ValueError):
            continue
        lineas.append({
            "id": pid,
            "cantidad": _a_float(it["cantidad"]),
            "precio": _a_float(it["precio_unitario"]),
            "descuento": _a_float(it["descuento"] or 0)
        })

    clientes = ClienteModel.listar_activos()
    return render_template(
        "ventas/formulario.html",
        venta=venta,
        lineas=lineas,
        id_cliente=id_cliente,
        clientes=clientes,
        catalogo=catalogo
    )


@venta_bp.route("/nueva", methods=["GET", "POST"])
@login_requerido
def nueva():
    if request.method == "POST":
        id_cliente = request.form.get("id_cliente", type=int)
        observacion = request.form.get("observacion", "").strip()[:500]
        confirmar = request.form.get("accion") == "confirmar"
        try:
            items = leer_items()
            id_venta = VentaModel.guardar(
                id_cliente, items, observacion,
                session["usuario_id"], confirmar=confirmar)
            flash(
                "Venta confirmada: stock descontado y despacho generado."
                if confirmar else
                "Venta guardada como BORRADOR.",
                "success"
            )
            return redirect(url_for("ventas.detalle", id_venta=id_venta))
        except ValueError as error:
            flash(str(error), "danger")
        except MySQLError:
            flash("No se pudo registrar la venta.", "danger")

        items_form = [
            {"id_producto": p, "cantidad": c, "precio_unitario": pr,
             "descuento": d}
            for p, c, pr, d in zip(
                request.form.getlist("id_producto[]"),
                request.form.getlist("cantidad[]"),
                request.form.getlist("precio[]"),
                request.form.getlist("descuento[]"))
        ]
        return _render_formulario(
            venta={"observacion": observacion},
            items=items_form, id_cliente=id_cliente)

    return _render_formulario(
        id_cliente=request.args.get("cliente", type=int))


@venta_bp.route("/<int:id_venta>/editar", methods=["GET", "POST"])
@login_requerido
def editar(id_venta):
    venta = VentaModel.obtener(id_venta)
    if not venta:
        abort(404)
    if venta["estado"] != "BORRADOR":
        flash("Solo se pueden editar ventas en BORRADOR.", "warning")
        return redirect(url_for("ventas.detalle", id_venta=id_venta))

    if request.method == "POST":
        id_cliente = request.form.get("id_cliente", type=int)
        observacion = request.form.get("observacion", "").strip()[:500]
        confirmar = request.form.get("accion") == "confirmar"
        try:
            items = leer_items()
            VentaModel.guardar(
                id_cliente, items, observacion, session["usuario_id"],
                confirmar=confirmar, id_venta=id_venta)
            flash("Venta confirmada." if confirmar
                  else "Borrador actualizado.", "success")
            return redirect(url_for("ventas.detalle", id_venta=id_venta))
        except ValueError as error:
            flash(str(error), "danger")
        except MySQLError:
            flash("No se pudo actualizar la venta.", "danger")

    items = [
        {"id_producto": d["id_producto"], "cantidad": d["cantidad"],
         "precio_unitario": d["precio_unitario"],
         "descuento": d["descuento"]}
        for d in venta["detalles"]
    ]
    return _render_formulario(venta=venta, items=items,
                              id_cliente=venta["id_cliente"])


# ==========================================
# DETALLE Y ACCIONES
# ==========================================

@venta_bp.route("/<int:id_venta>")
@login_requerido
def detalle(id_venta):
    venta = VentaModel.obtener(id_venta)
    if not venta:
        abort(404)
    return render_template("ventas/detalle.html", venta=venta,
                           metodos=METODOS_PAGO)


@venta_bp.route("/<int:id_venta>/nota")
@login_requerido
def nota(id_venta):
    venta = VentaModel.obtener(id_venta)
    if not venta:
        abort(404)
    return render_template("ventas/nota.html", venta=venta,
                           ahora=datetime.now())


@venta_bp.route("/<int:id_venta>/confirmar", methods=["POST"])
@login_requerido
def confirmar(id_venta):
    try:
        VentaModel.confirmar(id_venta, session["usuario_id"])
        flash("Venta confirmada: stock descontado por FEFO y "
              "despacho generado.", "success")
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo confirmar la venta.", "danger")
    return redirect(url_for("ventas.detalle", id_venta=id_venta))


@venta_bp.route("/<int:id_venta>/entregar", methods=["POST"])
@login_requerido
def entregar(id_venta):
    try:
        VentaModel.entregar(id_venta)
        flash("Venta marcada como ENTREGADA.", "success")
    except ValueError as error:
        flash(str(error), "danger")
    return redirect(url_for("ventas.detalle", id_venta=id_venta))


@venta_bp.route("/<int:id_venta>/anular", methods=["POST"])
@login_requerido
def anular(id_venta):
    motivo = request.form.get("motivo", "").strip()[:200]
    try:
        if not motivo:
            raise ValueError("Indique el motivo de la anulación.")
        VentaModel.anular(id_venta, session["usuario_id"], motivo)
        flash("Venta anulada. El stock fue devuelto a sus lotes.",
              "warning")
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo anular la venta.", "danger")
    return redirect(url_for("ventas.detalle", id_venta=id_venta))


@venta_bp.route("/<int:id_venta>/pago", methods=["POST"])
@login_requerido
def pago(id_venta):
    try:
        monto = a_decimal(request.form.get("monto", ""), "El monto",
                          decimales=2, permitir_cero=False)
        VentaModel.registrar_pago(
            id_venta, monto,
            request.form.get("metodo", "").upper(),
            request.form.get("referencia", "").strip()[:100],
            session["usuario_id"])
        flash("Pago registrado correctamente.", "success")
    except ValueError as error:
        flash(str(error), "danger")
    except MySQLError:
        flash("No se pudo registrar el pago.", "danger")
    return redirect(url_for("ventas.detalle", id_venta=id_venta))
