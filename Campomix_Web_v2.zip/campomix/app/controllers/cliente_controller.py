import re

from flask import (
    Blueprint, render_template, request,
    redirect, url_for, flash, abort
)
from mysql.connector import IntegrityError

from app.models.cliente_model import ClienteModel, TIPOS_CLIENTE
from app.models.venta_model import VentaModel
from app.utils import login_requerido


cliente_bp = Blueprint("clientes", __name__, url_prefix="/clientes")

PATRON_CORREO = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
PATRON_TELEFONO = re.compile(r"^[0-9+\-\s()]{6,30}$")
PATRON_DOCUMENTO = re.compile(r"^[A-Za-z0-9\-]{4,35}$")


def obtener_datos():
    return {
        "nombre": request.form.get("nombre", "").strip(),
        "tipo_cliente": request.form.get("tipo_cliente", "MINORISTA"),
        "documento": request.form.get("documento", "").strip().upper(),
        "telefono": request.form.get("telefono", "").strip(),
        "correo": request.form.get("correo", "").strip().lower(),
        "direccion": request.form.get("direccion", "").strip(),
        "observacion": request.form.get("observacion", "").strip(),
    }


def validar(d, excluir_id=None):
    errores = []
    if len(d["nombre"]) < 3:
        errores.append("El nombre o razón social debe tener al menos 3 caracteres.")
    elif len(d["nombre"]) > 160:
        errores.append("El nombre no puede superar 160 caracteres.")

    if d["tipo_cliente"] not in TIPOS_CLIENTE:
        errores.append("Seleccione un tipo de cliente válido.")

    if d["documento"]:
        if not PATRON_DOCUMENTO.match(d["documento"]):
            errores.append("El CI/NIT solo admite letras, números y guiones (4 a 35).")
        elif ClienteModel.existe_documento(d["documento"], excluir_id):
            errores.append("Ya existe un cliente con ese CI/NIT.")

    if d["telefono"] and not PATRON_TELEFONO.match(d["telefono"]):
        errores.append("El teléfono no tiene un formato válido.")

    if d["correo"] and (len(d["correo"]) > 150
                        or not PATRON_CORREO.match(d["correo"])):
        errores.append("El correo electrónico no es válido.")

    if len(d["direccion"]) > 255:
        errores.append("La dirección no puede superar 255 caracteres.")
    if len(d["observacion"]) > 255:
        errores.append("La observación no puede superar 255 caracteres.")
    return errores


@cliente_bp.route("/")
@login_requerido
def listar():
    busqueda = request.args.get("buscar", "").strip()
    tipo = request.args.get("tipo", "").strip().upper()
    estado = request.args.get("estado", "").strip()
    return render_template(
        "clientes/listar.html",
        clientes=ClienteModel.listar(busqueda, tipo, estado),
        resumen=ClienteModel.resumen(),
        tipos=TIPOS_CLIENTE,
        busqueda=busqueda, tipo=tipo, estado=estado
    )


@cliente_bp.route("/nuevo", methods=["GET", "POST"])
@login_requerido
def nuevo():
    datos = {"tipo_cliente": "MINORISTA"}
    if request.method == "POST":
        datos = obtener_datos()
        errores = validar(datos)
        if not errores:
            try:
                id_cliente = ClienteModel.crear(datos)
                flash("Cliente registrado correctamente.", "success")
                if request.form.get("volver_venta") == "1":
                    return redirect(url_for("ventas.nueva",
                                            cliente=id_cliente))
                return redirect(url_for("clientes.detalle",
                                        id_cliente=id_cliente))
            except IntegrityError:
                errores.append("El CI/NIT ya está registrado.")
        for e in errores:
            flash(e, "danger")

    return render_template("clientes/formulario.html", cliente=datos,
                           tipos=TIPOS_CLIENTE, modo="nuevo",
                           volver_venta=request.args.get("venta") == "1"
                           or request.form.get("volver_venta") == "1")


@cliente_bp.route("/<int:id_cliente>/editar", methods=["GET", "POST"])
@login_requerido
def editar(id_cliente):
    cliente = ClienteModel.obtener(id_cliente)
    if not cliente:
        abort(404)

    if request.method == "POST":
        datos = obtener_datos()
        errores = validar(datos, id_cliente)
        if not errores:
            try:
                ClienteModel.actualizar(id_cliente, datos)
                flash("Cliente actualizado correctamente.", "success")
                return redirect(url_for("clientes.detalle",
                                        id_cliente=id_cliente))
            except IntegrityError:
                errores.append("El CI/NIT ya está registrado.")
        for e in errores:
            flash(e, "danger")
        datos["id_cliente"] = id_cliente
        cliente = datos

    return render_template("clientes/formulario.html", cliente=cliente,
                           tipos=TIPOS_CLIENTE, modo="editar")


@cliente_bp.route("/<int:id_cliente>")
@login_requerido
def detalle(id_cliente):
    cliente = ClienteModel.obtener(id_cliente)
    if not cliente:
        abort(404)
    return render_template(
        "clientes/detalle.html",
        cliente=cliente,
        stats=ClienteModel.estadisticas(id_cliente),
        ventas=VentaModel.listar(id_cliente=id_cliente)
    )


@cliente_bp.route("/<int:id_cliente>/estado", methods=["POST"])
@login_requerido
def cambiar_estado(id_cliente):
    if ClienteModel.cambiar_estado(id_cliente):
        flash("Estado del cliente actualizado.", "success")
    else:
        flash("El cliente no existe.", "danger")
    return redirect(request.referrer or url_for("clientes.listar"))
