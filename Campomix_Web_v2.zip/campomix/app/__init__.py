from datetime import timedelta, datetime

from flask import (
    Flask, redirect, url_for,
    session, render_template
)

from config import Config

from app.utils import registrar_filtros, login_requerido

from app.controllers.auth_controller import auth_bp
from app.controllers.proveedor_controller import proveedor_bp
from app.controllers.materia_prima_controller import materia_prima_bp
from app.controllers.recepcion_mp_controller import recepcion_mp_bp
from app.controllers.lote_mp_controller import lote_mp_bp
from app.controllers.inventario_mp_controller import inventario_mp_bp
from app.controllers.categoria_producto_controller import categoria_producto_bp
from app.controllers.producto_controller import producto_bp
from app.controllers.receta_controller import receta_bp
from app.controllers.orden_produccion_controller import orden_produccion_bp

# Nuevos módulos v2.0
from app.controllers.producto_terminado_controller import producto_terminado_bp
from app.controllers.cliente_controller import cliente_bp
from app.controllers.venta_controller import venta_bp

from app.models.dashboard_model import DashboardModel


def create_app():

    app = Flask(__name__)

    # Configuración general
    app.config.from_object(Config)

    app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=30)
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

    registrar_filtros(app)

    # Registrar controladores
    app.register_blueprint(auth_bp)
    app.register_blueprint(proveedor_bp)
    app.register_blueprint(materia_prima_bp)
    app.register_blueprint(recepcion_mp_bp)
    app.register_blueprint(lote_mp_bp)
    app.register_blueprint(inventario_mp_bp)
    app.register_blueprint(categoria_producto_bp)
    app.register_blueprint(producto_bp)
    app.register_blueprint(receta_bp)
    app.register_blueprint(orden_produccion_bp)
    app.register_blueprint(producto_terminado_bp)
    app.register_blueprint(cliente_bp)
    app.register_blueprint(venta_bp)

    # Datos disponibles en todas las plantillas
    @app.context_processor
    def datos_globales():
        menu = {}
        if "usuario_id" in session:
            try:
                menu = DashboardModel.contadores_menu() or {}
            except Exception:
                menu = {}
        return {"menu_badges": menu, "hoy": datetime.now()}

    # Página principal
    @app.route("/")
    def inicio():
        if "usuario_id" in session:
            return redirect(url_for("dashboard"))
        return redirect(url_for("auth.login"))

    # Dashboard
    @app.route("/dashboard")
    @login_requerido
    def dashboard():
        return render_template("dashboard.html",
                               datos=DashboardModel.datos())

    # Páginas de error
    @app.errorhandler(404)
    def no_encontrado(error):
        return render_template("errores/error.html", codigo=404,
                               titulo="Página no encontrada",
                               mensaje="El recurso que busca no existe "
                                       "o fue movido."), 404

    @app.errorhandler(500)
    def error_interno(error):
        return render_template("errores/error.html", codigo=500,
                               titulo="Error interno",
                               mensaje="Ocurrió un problema inesperado. "
                                       "Intente nuevamente."), 500

    return app
