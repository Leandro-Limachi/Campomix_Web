"""
Utilidades compartidas del sistema Campomix:
- Decorador de sesión
- Conversión y validación de números decimales
- Filtros de formato para las plantillas Jinja
"""

from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import wraps

from flask import redirect, session, url_for, flash


# ==========================================================
# SESIÓN
# ==========================================================

def login_requerido(funcion):
    @wraps(funcion)
    def decorador(*args, **kwargs):
        if "usuario_id" not in session:
            flash("Inicie sesión para continuar.", "warning")
            return redirect(url_for("auth.login"))
        return funcion(*args, **kwargs)
    return decorador


# ==========================================================
# DECIMALES
# ==========================================================

TRES = Decimal("0.001")
DOS = Decimal("0.01")


def a_decimal(valor, nombre="El valor", decimales=3,
              minimo=None, permitir_cero=True,
              permitir_negativo=False):
    """Convierte texto a Decimal validando formato y rango."""
    try:
        texto = str(valor).strip().replace(",", ".")
        if texto == "":
            raise ValueError()
        numero = Decimal(texto)
        if not numero.is_finite():
            raise ValueError()
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f"{nombre} debe ser un número válido.")

    if numero.as_tuple().exponent < -decimales:
        raise ValueError(
            f"{nombre} admite como máximo {decimales} decimales."
        )
    if not permitir_negativo and numero < 0:
        raise ValueError(f"{nombre} no puede ser negativo.")
    if not permitir_cero and numero == 0:
        raise ValueError(f"{nombre} debe ser mayor que cero.")
    if minimo is not None and numero < minimo:
        raise ValueError(f"{nombre} debe ser mayor o igual a {minimo}.")
    if abs(numero) > Decimal("999999999999.999"):
        raise ValueError(f"{nombre} es demasiado grande.")
    return numero


def q3(valor):
    return Decimal(str(valor)).quantize(TRES, rounding=ROUND_HALF_UP)


def q2(valor):
    return Decimal(str(valor)).quantize(DOS, rounding=ROUND_HALF_UP)


# ==========================================================
# FILTROS JINJA
# ==========================================================

def filtro_bs(valor):
    """Formato de moneda boliviana: Bs 1.234,50"""
    try:
        numero = Decimal(str(valor or 0)).quantize(DOS, rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return "Bs 0,00"
    texto = f"{numero:,.2f}"
    texto = texto.replace(",", "X").replace(".", ",").replace("X", ".")
    return f"Bs {texto}"


def filtro_num(valor, decimales=3):
    """Cantidad sin ceros innecesarios: 12.500 -> 12,5"""
    try:
        numero = Decimal(str(valor or 0))
    except InvalidOperation:
        return "0"
    numero = numero.quantize(Decimal(1).scaleb(-decimales),
                             rounding=ROUND_HALF_UP)
    texto = f"{numero:,.{decimales}f}"
    if "." in texto:
        texto = texto.rstrip("0").rstrip(".")
    texto = texto.replace(",", "X").replace(".", ",").replace("X", ".")
    return texto


def filtro_fecha(valor, formato="%d/%m/%Y"):
    if not valor:
        return "—"
    if isinstance(valor, (datetime, date)):
        return valor.strftime(formato)
    return str(valor)


def filtro_fecha_hora(valor):
    return filtro_fecha(valor, "%d/%m/%Y %H:%M")


def registrar_filtros(app):
    app.jinja_env.filters["bs"] = filtro_bs
    app.jinja_env.filters["num"] = filtro_num
    app.jinja_env.filters["fecha"] = filtro_fecha
    app.jinja_env.filters["fecha_hora"] = filtro_fecha_hora
