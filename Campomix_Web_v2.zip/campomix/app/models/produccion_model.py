"""
Ejecución de órdenes de producción.

Flujo:
  PLANIFICADA --(iniciar)--> EN_PROCESO --(finalizar)--> FINALIZADA
       |                          |
       +------(cancelar)----------+--> CANCELADA

- Al INICIAR se consumen las materias primas usando FEFO
  (primero en vencer, primero en salir) solo de lotes APROBADOS
  y vigentes. Se registran consumos_produccion y movimientos_mp.
- Al FINALIZAR se crea el lote de producto terminado (lotes_pt)
  en CUARENTENA y su movimiento de ingreso (movimientos_pt).
- Al CANCELAR una orden EN_PROCESO se devuelven las materias
  primas consumidas a sus lotes de origen.
"""

from datetime import date, timedelta
from decimal import Decimal

from app.database.conexion import obtener_conexion
from app.utils import q3


def _almacen_por_tipo(cursor, tipo):
    cursor.execute("""
        SELECT id_almacen
        FROM almacenes
        WHERE tipo IN (%s, 'MIXTO') AND activo = 1
        ORDER BY (tipo = %s) DESC, id_almacen
        LIMIT 1
    """, (tipo, tipo))
    fila = cursor.fetchone()
    if not fila:
        raise ValueError(
            f"No existe un almacén activo de tipo {tipo}."
        )
    return fila["id_almacen"]


class ProduccionModel:

    # ------------------------------------------------------
    # INICIAR: consumo de materias primas (FEFO)
    # ------------------------------------------------------
    @staticmethod
    def iniciar(id_orden, id_usuario):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            conexion.start_transaction()

            cursor.execute("""
                SELECT o.id_orden, o.numero, o.estado,
                       o.cantidad_planificada,
                       r.id_receta, r.cantidad_base, r.estado AS estado_receta
                FROM ordenes_produccion o
                INNER JOIN recetas r ON r.id_receta = o.id_receta
                WHERE o.id_orden = %s
                FOR UPDATE
            """, (id_orden,))
            orden = cursor.fetchone()

            if not orden:
                raise ValueError("La orden no existe.")
            if orden["estado"] != "PLANIFICADA":
                raise ValueError(
                    "Solo se pueden iniciar órdenes PLANIFICADAS."
                )

            factor = (Decimal(str(orden["cantidad_planificada"]))
                      / Decimal(str(orden["cantidad_base"])))

            cursor.execute("""
                SELECT d.id_materia, d.cantidad,
                       m.nombre, u.simbolo
                FROM receta_detalles d
                INNER JOIN materias_primas m ON m.id_materia = d.id_materia
                INNER JOIN unidades_medida u ON u.id_unidad = m.id_unidad
                WHERE d.id_receta = %s
            """, (orden["id_receta"],))
            ingredientes = cursor.fetchall()

            if not ingredientes:
                raise ValueError("La receta no tiene ingredientes.")

            faltantes = []
            asignaciones = []

            for ing in ingredientes:
                necesario = q3(Decimal(str(ing["cantidad"])) * factor)
                if necesario <= 0:
                    continue

                # Bloquear lotes de la materia prima
                cursor.execute("""
                    SELECT id_lote_mp FROM lotes_mp
                    WHERE id_materia = %s
                    FOR UPDATE
                """, (ing["id_materia"],))
                cursor.fetchall()

                # Saldos por lote/almacén, FEFO
                cursor.execute("""
                    SELECT l.id_lote_mp, l.codigo_lote,
                           mov.id_almacen,
                           SUM(mov.cantidad_firmada) AS saldo
                    FROM lotes_mp l
                    INNER JOIN movimientos_mp mov
                        ON mov.id_lote_mp = l.id_lote_mp
                    INNER JOIN almacenes a
                        ON a.id_almacen = mov.id_almacen
                       AND a.tipo IN ('MP', 'MIXTO')
                    WHERE l.id_materia = %s
                      AND l.estado_calidad = 'APROBADO'
                      AND (l.fecha_vencimiento IS NULL
                           OR l.fecha_vencimiento >= CURDATE())
                    GROUP BY l.id_lote_mp, l.codigo_lote,
                             mov.id_almacen, l.fecha_vencimiento,
                             l.fecha_recepcion
                    HAVING saldo > 0
                    ORDER BY (l.fecha_vencimiento IS NULL),
                             l.fecha_vencimiento,
                             l.fecha_recepcion,
                             l.id_lote_mp
                """, (ing["id_materia"],))
                lotes = cursor.fetchall()

                pendiente = necesario
                for lote in lotes:
                    if pendiente <= 0:
                        break
                    saldo = Decimal(str(lote["saldo"]))
                    tomar = min(saldo, pendiente)
                    asignaciones.append(
                        (lote["id_lote_mp"], lote["id_almacen"], tomar)
                    )
                    pendiente -= tomar

                if pendiente > 0:
                    faltantes.append(
                        f"{ing['nombre']}: faltan "
                        f"{q3(pendiente).normalize():f} {ing['simbolo']}"
                    )

            if faltantes:
                raise ValueError(
                    "Stock insuficiente de materias primas aprobadas. "
                    + " | ".join(faltantes)
                )

            for id_lote, id_almacen, cantidad in asignaciones:
                cursor.execute("""
                    INSERT INTO consumos_produccion
                        (id_orden, id_lote_mp, id_almacen, cantidad)
                    VALUES (%s, %s, %s, %s)
                """, (id_orden, id_lote, id_almacen, cantidad))

                cursor.execute("""
                    INSERT INTO movimientos_mp
                        (id_lote_mp, id_almacen, cantidad_firmada, tipo,
                         referencia_tipo, referencia_id, id_usuario,
                         observacion)
                    VALUES (%s, %s, %s, 'CONSUMO',
                            'ORDEN_PRODUCCION', %s, %s, %s)
                """, (id_lote, id_almacen, -cantidad, id_orden,
                      id_usuario,
                      f"Consumo por orden {orden['numero']}"))

            cursor.execute("""
                UPDATE ordenes_produccion
                SET estado = 'EN_PROCESO', fecha_inicio = NOW()
                WHERE id_orden = %s
            """, (id_orden,))

            conexion.commit()

        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # FINALIZAR: genera lote de producto terminado
    # ------------------------------------------------------
    @staticmethod
    def finalizar(id_orden, cantidad_obtenida, fecha_vencimiento,
                  id_usuario, observacion=""):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            conexion.start_transaction()

            cursor.execute("""
                SELECT o.id_orden, o.numero, o.estado,
                       p.id_producto, p.codigo, p.vida_util_dias
                FROM ordenes_produccion o
                INNER JOIN recetas r ON r.id_receta = o.id_receta
                INNER JOIN productos p ON p.id_producto = r.id_producto
                WHERE o.id_orden = %s
                FOR UPDATE
            """, (id_orden,))
            orden = cursor.fetchone()

            if not orden:
                raise ValueError("La orden no existe.")
            if orden["estado"] != "EN_PROCESO":
                raise ValueError(
                    "Solo se pueden finalizar órdenes EN PROCESO."
                )

            cantidad = q3(cantidad_obtenida)
            if cantidad < 0:
                raise ValueError("La cantidad obtenida no es válida.")

            hoy = date.today()
            if fecha_vencimiento is None:
                dias = orden["vida_util_dias"] or 30
                fecha_vencimiento = hoy + timedelta(days=int(dias))

            if fecha_vencimiento < hoy:
                raise ValueError(
                    "La fecha de vencimiento no puede ser anterior a hoy."
                )

            if cantidad > 0:
                codigo_lote = (
                    f"PT-{orden['codigo']}-{hoy:%y%m%d}-{id_orden:04d}"
                )
                id_almacen = _almacen_por_tipo(cursor, "PT")

                cursor.execute("""
                    INSERT INTO lotes_pt
                        (id_producto, id_orden, codigo_lote,
                         fecha_fabricacion, fecha_vencimiento,
                         cantidad_producida, estado_calidad,
                         observacion)
                    VALUES (%s, %s, %s, %s, %s, %s, 'CUARENTENA', %s)
                """, (orden["id_producto"], id_orden, codigo_lote,
                      hoy, fecha_vencimiento, cantidad,
                      observacion or None))
                id_lote = cursor.lastrowid

                cursor.execute("""
                    INSERT INTO movimientos_pt
                        (id_lote_pt, id_almacen, cantidad_firmada, tipo,
                         referencia_tipo, referencia_id, id_usuario,
                         observacion)
                    VALUES (%s, %s, %s, 'PRODUCCION',
                            'ORDEN_PRODUCCION', %s, %s, %s)
                """, (id_lote, id_almacen, cantidad, id_orden,
                      id_usuario,
                      f"Ingreso por orden {orden['numero']}"))

            cursor.execute("""
                UPDATE ordenes_produccion
                SET estado = 'FINALIZADA',
                    fecha_fin = NOW(),
                    cantidad_obtenida = %s,
                    observacion = CONCAT_WS('\n', NULLIF(observacion, ''),
                                            NULLIF(%s, ''))
                WHERE id_orden = %s
            """, (cantidad, observacion, id_orden))

            conexion.commit()

        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # CANCELAR: devuelve materias primas si ya se consumieron
    # ------------------------------------------------------
    @staticmethod
    def cancelar(id_orden, id_usuario, motivo):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            conexion.start_transaction()

            cursor.execute("""
                SELECT id_orden, numero, estado
                FROM ordenes_produccion
                WHERE id_orden = %s
                FOR UPDATE
            """, (id_orden,))
            orden = cursor.fetchone()

            if not orden:
                raise ValueError("La orden no existe.")
            if orden["estado"] not in ("PLANIFICADA", "EN_PROCESO"):
                raise ValueError(
                    "Solo se pueden cancelar órdenes planificadas "
                    "o en proceso."
                )

            if orden["estado"] == "EN_PROCESO":
                cursor.execute("""
                    SELECT id_lote_mp, id_almacen, cantidad
                    FROM consumos_produccion
                    WHERE id_orden = %s
                """, (id_orden,))
                for c in cursor.fetchall():
                    cursor.execute("""
                        INSERT INTO movimientos_mp
                            (id_lote_mp, id_almacen, cantidad_firmada,
                             tipo, referencia_tipo, referencia_id,
                             id_usuario, observacion)
                        VALUES (%s, %s, %s, 'DEVOLUCION',
                                'ORDEN_PRODUCCION', %s, %s, %s)
                    """, (c["id_lote_mp"], c["id_almacen"],
                          c["cantidad"], id_orden, id_usuario,
                          f"Devolución por cancelación de {orden['numero']}"))

            cursor.execute("""
                UPDATE ordenes_produccion
                SET estado = 'CANCELADA',
                    fecha_fin = NOW(),
                    observacion = CONCAT_WS('\n', NULLIF(observacion, ''),
                                            %s)
                WHERE id_orden = %s
            """, (f"Cancelada: {motivo}", id_orden))

            conexion.commit()

        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # CONSULTAS
    # ------------------------------------------------------
    @staticmethod
    def consumos(id_orden):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT c.cantidad, c.fecha,
                       l.codigo_lote, l.fecha_vencimiento,
                       m.codigo, m.nombre AS materia_prima,
                       u.simbolo AS unidad
                FROM consumos_produccion c
                INNER JOIN lotes_mp l ON l.id_lote_mp = c.id_lote_mp
                INNER JOIN materias_primas m ON m.id_materia = l.id_materia
                INNER JOIN unidades_medida u ON u.id_unidad = m.id_unidad
                WHERE c.id_orden = %s
                ORDER BY m.nombre, l.fecha_vencimiento
            """, (id_orden,))
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def lotes_generados(id_orden):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT l.*,
                       COALESCE((SELECT SUM(cantidad_firmada)
                                 FROM movimientos_pt mv
                                 WHERE mv.id_lote_pt = l.id_lote_pt), 0)
                           AS stock
                FROM lotes_pt l
                WHERE l.id_orden = %s
            """, (id_orden,))
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def resumen_estados():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT estado, COUNT(*) AS total
                FROM ordenes_produccion
                GROUP BY estado
            """)
            datos = {f["estado"]: f["total"] for f in cursor.fetchall()}
            for e in ("PLANIFICADA", "EN_PROCESO", "FINALIZADA",
                      "CANCELADA"):
                datos.setdefault(e, 0)
            return datos
        finally:
            cursor.close()
            conexion.close()
