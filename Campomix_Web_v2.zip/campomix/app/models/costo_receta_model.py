
from decimal import Decimal

from app.database.conexion import obtener_conexion


class CostoRecetaModel:

    @staticmethod
    def obtener_costos_materias():
        """
        Calcula el costo promedio ponderado de cada
        materia prima a partir de recepciones confirmadas.
        """

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    l.id_materia,
                    SUM(
                        d.cantidad * d.costo_unitario
                    ) / NULLIF(SUM(d.cantidad), 0)
                        AS costo_promedio,

                    SUM(d.cantidad)
                        AS cantidad_recibida

                FROM recepcion_mp_detalles d

                INNER JOIN recepciones_mp r
                    ON d.id_recepcion = r.id_recepcion

                INNER JOIN lotes_mp l
                    ON d.id_lote_mp = l.id_lote_mp

                WHERE r.estado = 'CONFIRMADA'

                GROUP BY l.id_materia
            """)

            resultados = cursor.fetchall()

            return {
                fila["id_materia"]: {
                    "costo_promedio": Decimal(
                        str(fila["costo_promedio"])
                    ),
                    "cantidad_recibida": Decimal(
                        str(fila["cantidad_recibida"])
                    )
                }
                for fila in resultados
                if fila["costo_promedio"] is not None
            }

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def calcular_costo_receta(id_receta):

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    r.id_receta,
                    r.cantidad_base,
                    d.id_materia,
                    d.cantidad,
                    m.nombre AS materia_prima,
                    u.simbolo AS unidad

                FROM recetas r

                INNER JOIN receta_detalles d
                    ON r.id_receta = d.id_receta

                INNER JOIN materias_primas m
                    ON d.id_materia = m.id_materia

                INNER JOIN unidades_medida u
                    ON m.id_unidad = u.id_unidad

                WHERE r.id_receta = %s

                ORDER BY m.nombre
            """, (id_receta,))

            ingredientes = cursor.fetchall()

        finally:
            cursor.close()
            conexion.close()

        costos = CostoRecetaModel.obtener_costos_materias()

        detalles = []
        costo_total = Decimal("0")
        costos_faltantes = False

        for ingrediente in ingredientes:

            id_materia = ingrediente["id_materia"]

            cantidad = Decimal(
                str(ingrediente["cantidad"])
            )

            informacion = costos.get(id_materia)

            if informacion is None:
                costo_unitario = None
                subtotal = None
                costos_faltantes = True

            else:
                costo_unitario = informacion[
                    "costo_promedio"
                ]

                subtotal = cantidad * costo_unitario

                costo_total += subtotal

            detalles.append({
                "id_materia": id_materia,
                "materia_prima": ingrediente["materia_prima"],
                "unidad": ingrediente["unidad"],
                "cantidad": cantidad,
                "costo_unitario": costo_unitario,
                "subtotal": subtotal
            })

        cantidad_base = (
            Decimal(str(ingredientes[0]["cantidad_base"]))
            if ingredientes
            else Decimal("0")
        )

        if (
            cantidad_base > 0
            and not costos_faltantes
            and detalles
        ):
            costo_unitario_producto = (
                costo_total / cantidad_base
            )
        else:
            costo_unitario_producto = None

        return {
            "detalles": detalles,
            "costo_total": (
                costo_total
                if not costos_faltantes and detalles
                else None
            ),
            "costo_unitario_producto": costo_unitario_producto,
            "costos_faltantes": costos_faltantes,
            "cantidad_base": cantidad_base
        }
