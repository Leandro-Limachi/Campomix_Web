
from decimal import Decimal

from app.database.conexion import obtener_conexion


class DisponibilidadMPModel:

    @staticmethod
    def obtener_existencias():
        """
        Obtiene el stock disponible de materias primas
        a partir de los movimientos de inventario.

        Solo considera lotes con calidad APROBADA.
        """

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    l.id_materia,
                    COALESCE(
                        SUM(m.cantidad_firmada), 0
                    ) AS stock_disponible

                FROM lotes_mp l

                INNER JOIN movimientos_mp m
                    ON l.id_lote_mp = m.id_lote_mp

                WHERE l.estado_calidad = 'APROBADO'
                  AND (
                      l.fecha_vencimiento IS NULL
                      OR l.fecha_vencimiento >= CURDATE()
                  )

                GROUP BY l.id_materia
            """)

            resultados = cursor.fetchall()

            return {
                fila["id_materia"]: Decimal(
                    str(fila["stock_disponible"])
                )
                for fila in resultados
            }

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def verificar_receta(id_receta, cantidad_planificada):

        from app.models.orden_produccion_model import (
            OrdenProduccionModel
        )

        calculo = OrdenProduccionModel.calcular_ingredientes(
            id_receta,
            cantidad_planificada
        )

        existencias = (
            DisponibilidadMPModel.obtener_existencias()
        )

        ingredientes = []
        produccion_posible = True

        for item in calculo["ingredientes"]:

            id_materia = item["id_materia"]

            cantidad_necesaria = Decimal(
                str(item["cantidad_necesaria"])
            )

            stock = existencias.get(
                id_materia,
                Decimal("0")
            )

            faltante = max(
                cantidad_necesaria - stock,
                Decimal("0")
            )

            suficiente = stock >= cantidad_necesaria

            if not suficiente:
                produccion_posible = False

            ingredientes.append({
                "id_materia": id_materia,
                "codigo": item["codigo"],
                "materia_prima": item["materia_prima"],
                "unidad": item["unidad"],
                "cantidad_necesaria": cantidad_necesaria,
                "stock_disponible": stock,
                "faltante": faltante,
                "suficiente": suficiente
            })

        return {
            "produccion_posible": (
                produccion_posible and len(ingredientes) > 0
            ),
            "ingredientes": ingredientes,
            "cantidad_planificada": (
                calculo["cantidad_planificada"]
            )
        }
