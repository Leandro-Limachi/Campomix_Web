from datetime import date, timedelta
from decimal import Decimal

from app.database.conexion import obtener_conexion


MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
         "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]


class DashboardModel:

    @staticmethod
    def datos():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            d = {}

            cursor.execute("""
                SELECT
                    (SELECT COUNT(*) FROM proveedores WHERE activo = 1)
                        AS proveedores,
                    (SELECT COUNT(*) FROM materias_primas WHERE activo = 1)
                        AS materias,
                    (SELECT COUNT(*) FROM productos WHERE activo = 1)
                        AS productos,
                    (SELECT COUNT(*) FROM clientes WHERE activo = 1)
                        AS clientes,
                    (SELECT COUNT(*) FROM ordenes_produccion
                        WHERE estado IN ('PLANIFICADA','EN_PROCESO'))
                        AS ordenes_activas,
                    (SELECT COUNT(*) FROM ordenes_produccion
                        WHERE estado = 'FINALIZADA') AS ordenes_finalizadas
            """)
            d["contadores"] = cursor.fetchone()

            cursor.execute("""
                SELECT
                  COALESCE(SUM(CASE WHEN DATE(fecha) = CURDATE()
                      THEN total END), 0) AS hoy,
                  COALESCE(SUM(CASE WHEN YEAR(fecha) = YEAR(CURDATE())
                      AND MONTH(fecha) = MONTH(CURDATE())
                      THEN total END), 0) AS mes,
                  COALESCE(SUM(CASE WHEN fecha >= DATE_SUB(
                      DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 1 MONTH)
                      AND fecha < DATE_FORMAT(CURDATE(), '%Y-%m-01')
                      THEN total END), 0) AS mes_anterior,
                  COUNT(CASE WHEN YEAR(fecha) = YEAR(CURDATE())
                      AND MONTH(fecha) = MONTH(CURDATE()) THEN 1 END)
                      AS num_mes
                FROM ventas
                WHERE estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """)
            ventas = cursor.fetchone()
            ant = Decimal(str(ventas["mes_anterior"]))
            act = Decimal(str(ventas["mes"]))
            ventas["variacion"] = (
                float((act - ant) / ant * 100) if ant > 0 else None
            )

            cursor.execute("""
                SELECT COALESCE(SUM(v.total), 0)
                     - COALESCE((SELECT SUM(p.monto) FROM pagos_venta p
                        INNER JOIN ventas x ON x.id_venta = p.id_venta
                        WHERE x.estado IN
                            ('CONFIRMADA','PARCIAL','ENTREGADA')), 0)
                     AS por_cobrar
                FROM ventas v
                WHERE v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """)
            ventas["por_cobrar"] = cursor.fetchone()["por_cobrar"]
            d["ventas"] = ventas

            # Ventas últimos 14 días
            cursor.execute("""
                SELECT DATE(fecha) AS dia, SUM(total) AS total
                FROM ventas
                WHERE estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
                  AND fecha >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)
                GROUP BY DATE(fecha)
            """)
            por_dia = {f["dia"]: float(f["total"]) for f in cursor.fetchall()}
            hoy = date.today()
            dias = [hoy - timedelta(days=i) for i in range(13, -1, -1)]
            d["grafico_dias"] = {
                "labels": [x.strftime("%d/%m") for x in dias],
                "valores": [por_dia.get(x, 0) for x in dias],
            }

            # Ventas por categoría (mes actual)
            cursor.execute("""
                SELECT c.nombre,
                       SUM(dt.cantidad * dt.precio_unitario - dt.descuento)
                           AS total
                FROM venta_detalles dt
                INNER JOIN ventas v ON v.id_venta = dt.id_venta
                INNER JOIN productos p ON p.id_producto = dt.id_producto
                INNER JOIN categorias_producto c
                    ON c.id_categoria = p.id_categoria
                WHERE v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
                GROUP BY c.id_categoria, c.nombre
                ORDER BY total DESC
            """)
            cat = cursor.fetchall()
            d["grafico_categorias"] = {
                "labels": [c["nombre"] for c in cat],
                "valores": [float(c["total"]) for c in cat],
            }

            # Top productos
            cursor.execute("""
                SELECT p.nombre, u.simbolo AS unidad,
                       SUM(dt.cantidad) AS cantidad,
                       SUM(dt.cantidad * dt.precio_unitario - dt.descuento)
                           AS total
                FROM venta_detalles dt
                INNER JOIN ventas v ON v.id_venta = dt.id_venta
                INNER JOIN productos p ON p.id_producto = dt.id_producto
                INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
                WHERE v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
                GROUP BY p.id_producto, p.nombre, u.simbolo
                ORDER BY total DESC
                LIMIT 5
            """)
            d["top_productos"] = cursor.fetchall()
            maximo = max([float(t["total"]) for t in d["top_productos"]]
                         or [1])
            for t in d["top_productos"]:
                t["pct"] = int(float(t["total"]) * 100 / maximo) if maximo else 0

            # Últimas ventas
            cursor.execute("""
                SELECT v.id_venta, v.numero, v.fecha, v.total, v.estado,
                       c.nombre AS cliente
                FROM ventas v
                INNER JOIN clientes c ON c.id_cliente = v.id_cliente
                ORDER BY v.fecha DESC, v.id_venta DESC
                LIMIT 6
            """)
            d["ultimas_ventas"] = cursor.fetchall()

            # ALERTAS
            alertas = []

            cursor.execute("""
                SELECT l.id_lote_pt, l.codigo_lote, p.nombre,
                       DATEDIFF(l.fecha_vencimiento, CURDATE()) AS dias,
                       s.saldo
                FROM lotes_pt l
                INNER JOIN productos p ON p.id_producto = l.id_producto
                INNER JOIN (SELECT id_lote_pt, SUM(cantidad_firmada) saldo
                            FROM movimientos_pt GROUP BY id_lote_pt) s
                    ON s.id_lote_pt = l.id_lote_pt
                WHERE s.saldo > 0
                  AND l.estado_calidad <> 'BLOQUEADO'
                  AND l.fecha_vencimiento <= DATE_ADD(CURDATE(),
                                                      INTERVAL 7 DAY)
                ORDER BY l.fecha_vencimiento
                LIMIT 5
            """)
            for f in cursor.fetchall():
                vencido = f["dias"] < 0
                alertas.append({
                    "nivel": "danger" if vencido else "warning",
                    "icono": "bi-calendar-x" if vencido
                    else "bi-hourglass-split",
                    "titulo": f"Lote {f['codigo_lote']}",
                    "texto": (f"{f['nombre']} — vencido hace "
                              f"{-f['dias']} día(s)") if vencido else
                    (f"{f['nombre']} — vence en {f['dias']} día(s)"),
                    "url": ("productos_terminados.lote_detalle",
                            {"id_lote": f["id_lote_pt"]}),
                })

            cursor.execute("""
                SELECT COUNT(*) AS n FROM lotes_pt l
                WHERE l.estado_calidad = 'CUARENTENA'
                  AND EXISTS (SELECT 1 FROM movimientos_pt m
                              WHERE m.id_lote_pt = l.id_lote_pt
                              GROUP BY m.id_lote_pt
                              HAVING SUM(m.cantidad_firmada) > 0)
            """)
            n = cursor.fetchone()["n"]
            if n:
                alertas.append({
                    "nivel": "info", "icono": "bi-shield-exclamation",
                    "titulo": f"{n} lote(s) PT en cuarentena",
                    "texto": "Pendientes de control de calidad para venta.",
                    "url": ("productos_terminados.lotes",
                            {"estado": "CUARENTENA"}),
                })

            cursor.execute("""
                SELECT * FROM (
                    SELECT m.nombre, m.stock_minimo, u.simbolo,
                           COALESCE(SUM(CASE WHEN l.estado_calidad='APROBADO'
                               AND (l.fecha_vencimiento IS NULL
                                    OR l.fecha_vencimiento >= CURDATE())
                               THEN s.saldo END), 0) AS disponible
                    FROM materias_primas m
                    INNER JOIN unidades_medida u ON u.id_unidad = m.id_unidad
                    LEFT JOIN lotes_mp l ON l.id_materia = m.id_materia
                    LEFT JOIN (SELECT id_lote_mp, SUM(cantidad_firmada) saldo
                               FROM movimientos_mp GROUP BY id_lote_mp) s
                        ON s.id_lote_mp = l.id_lote_mp
                    WHERE m.activo = 1
                    GROUP BY m.id_materia, m.nombre, m.stock_minimo, u.simbolo
                ) x
                WHERE x.disponible < x.stock_minimo
                ORDER BY x.disponible / NULLIF(x.stock_minimo, 0)
                LIMIT 4
            """)
            for f in cursor.fetchall():
                alertas.append({
                    "nivel": "warning", "icono": "bi-box-seam",
                    "titulo": f"Stock bajo de MP: {f['nombre']}",
                    "texto": (f"Disponible {float(f['disponible']):g} "
                              f"{f['simbolo']} / mínimo "
                              f"{float(f['stock_minimo']):g}"),
                    "url": ("inventario_mp.listar", {}),
                })

            cursor.execute("""
                SELECT p.id_producto, p.nombre, p.stock_minimo,
                       u.simbolo,
                       COALESCE(SUM(CASE WHEN l.estado_calidad='LIBERADO'
                           AND l.fecha_vencimiento >= CURDATE()
                           THEN s.saldo END), 0) AS disponible
                FROM productos p
                INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
                LEFT JOIN lotes_pt l ON l.id_producto = p.id_producto
                LEFT JOIN (SELECT id_lote_pt, SUM(cantidad_firmada) saldo
                           FROM movimientos_pt GROUP BY id_lote_pt) s
                    ON s.id_lote_pt = l.id_lote_pt
                WHERE p.activo = 1 AND p.stock_minimo > 0
                GROUP BY p.id_producto, p.nombre, p.stock_minimo, u.simbolo
                HAVING disponible < p.stock_minimo
                LIMIT 4
            """)
            for f in cursor.fetchall():
                alertas.append({
                    "nivel": "warning", "icono": "bi-basket",
                    "titulo": f"Stock bajo de PT: {f['nombre']}",
                    "texto": (f"Disponible {float(f['disponible']):g} "
                              f"{f['simbolo']} / mínimo "
                              f"{float(f['stock_minimo']):g}"),
                    "url": ("productos_terminados.inventario", {}),
                })

            cursor.execute("""
                SELECT COUNT(*) AS n FROM ventas WHERE estado = 'BORRADOR'
            """)
            n = cursor.fetchone()["n"]
            if n:
                alertas.append({
                    "nivel": "secondary", "icono": "bi-file-earmark",
                    "titulo": f"{n} venta(s) en borrador",
                    "texto": "Revise y confirme las ventas pendientes.",
                    "url": ("ventas.listar", {"estado": "BORRADOR"}),
                })

            d["alertas"] = alertas
            d["mes_actual"] = MESES[hoy.month - 1]
            return d
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def contadores_menu():
        """Insignias del menú lateral."""
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT
                  (SELECT COUNT(*) FROM lotes_pt
                     WHERE estado_calidad = 'CUARENTENA') AS lotes_pt_cuarentena,
                  (SELECT COUNT(*) FROM ventas
                     WHERE estado = 'BORRADOR') AS ventas_borrador,
                  (SELECT COUNT(*) FROM ordenes_produccion
                     WHERE estado = 'EN_PROCESO') AS ordenes_en_proceso,
                  (SELECT COUNT(*) FROM lotes_mp
                     WHERE estado_calidad = 'CUARENTENA') AS lotes_mp_cuarentena
            """)
            return cursor.fetchone()
        finally:
            cursor.close()
            conexion.close()
