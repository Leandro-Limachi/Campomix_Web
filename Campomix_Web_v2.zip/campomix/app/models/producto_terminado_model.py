"""
Módulo de Productos Terminados (Almacén PT).

El stock se calcula siempre a partir de movimientos_pt
(kardex), nunca se guarda un saldo editable.
Stock DISPONIBLE para venta = lotes LIBERADOS y no vencidos.
"""

from decimal import Decimal

from app.database.conexion import obtener_conexion
from app.utils import q3


SALDOS_SQL = """
    SELECT mv.id_lote_pt, SUM(mv.cantidad_firmada) AS saldo
    FROM movimientos_pt mv
    INNER JOIN almacenes a
        ON a.id_almacen = mv.id_almacen
       AND a.tipo IN ('PT', 'MIXTO')
    GROUP BY mv.id_lote_pt
"""


class ProductoTerminadoModel:

    # ------------------------------------------------------
    # INVENTARIO CONSOLIDADO POR PRODUCTO
    # ------------------------------------------------------
    @staticmethod
    def inventario(busqueda="", id_categoria=None):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        filtros = ["(p.codigo LIKE %s OR p.nombre LIKE %s)"]
        params = [f"%{busqueda}%", f"%{busqueda}%"]
        if id_categoria:
            filtros.append("p.id_categoria = %s")
            params.append(id_categoria)

        try:
            cursor.execute(f"""
                SELECT
                    p.id_producto, p.codigo, p.nombre, p.activo,
                    p.precio_referencia, p.stock_minimo,
                    p.vida_util_dias,
                    c.nombre AS categoria,
                    u.simbolo AS unidad,
                    COUNT(DISTINCT CASE WHEN COALESCE(s.saldo,0) > 0
                          THEN l.id_lote_pt END) AS lotes_con_stock,
                    COALESCE(SUM(s.saldo), 0) AS stock_fisico,
                    COALESCE(SUM(CASE
                        WHEN l.estado_calidad = 'LIBERADO'
                         AND l.fecha_vencimiento >= CURDATE()
                        THEN s.saldo ELSE 0 END), 0) AS disponible,
                    COALESCE(SUM(CASE
                        WHEN l.estado_calidad = 'CUARENTENA'
                         AND l.fecha_vencimiento >= CURDATE()
                        THEN s.saldo ELSE 0 END), 0) AS cuarentena,
                    COALESCE(SUM(CASE
                        WHEN l.estado_calidad = 'BLOQUEADO'
                        THEN s.saldo ELSE 0 END), 0) AS bloqueado,
                    COALESCE(SUM(CASE
                        WHEN l.estado_calidad <> 'BLOQUEADO'
                         AND l.fecha_vencimiento < CURDATE()
                        THEN s.saldo ELSE 0 END), 0) AS vencido,
                    COALESCE(SUM(CASE
                        WHEN l.estado_calidad = 'LIBERADO'
                         AND l.fecha_vencimiento BETWEEN CURDATE()
                             AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                        THEN s.saldo ELSE 0 END), 0) AS por_vencer,
                    MIN(CASE WHEN COALESCE(s.saldo,0) > 0
                         AND l.fecha_vencimiento >= CURDATE()
                        THEN l.fecha_vencimiento END) AS proximo_vencimiento
                FROM productos p
                INNER JOIN categorias_producto c
                    ON c.id_categoria = p.id_categoria
                INNER JOIN unidades_medida u
                    ON u.id_unidad = p.id_unidad
                LEFT JOIN lotes_pt l
                    ON l.id_producto = p.id_producto
                LEFT JOIN ({SALDOS_SQL}) s
                    ON s.id_lote_pt = l.id_lote_pt
                WHERE {" AND ".join(filtros)}
                GROUP BY p.id_producto, p.codigo, p.nombre, p.activo,
                         p.precio_referencia, p.stock_minimo,
                         p.vida_util_dias, c.nombre, u.simbolo
                ORDER BY p.nombre
            """, params)

            filas = cursor.fetchall()
            for f in filas:
                disp = Decimal(str(f["disponible"]))
                minimo = Decimal(str(f["stock_minimo"]))
                f["valorizado"] = disp * Decimal(str(f["precio_referencia"]))
                if disp <= 0:
                    f["nivel"] = "AGOTADO"
                elif minimo > 0 and disp <= minimo:
                    f["nivel"] = "BAJO"
                else:
                    f["nivel"] = "OK"
                f["porcentaje"] = (
                    min(int(disp / (minimo * 2) * 100), 100)
                    if minimo > 0 else (100 if disp > 0 else 0)
                )
            return filas
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def resumen():
        filas = ProductoTerminadoModel.inventario()
        return {
            "productos": len(filas),
            "disponible_valor": sum(f["valorizado"] for f in filas),
            "agotados": sum(1 for f in filas
                            if f["nivel"] == "AGOTADO" and f["activo"]),
            "bajos": sum(1 for f in filas if f["nivel"] == "BAJO"),
            "cuarentena": sum(Decimal(str(f["cuarentena"])) for f in filas),
            "por_vencer": sum(1 for f in filas
                              if Decimal(str(f["por_vencer"])) > 0),
        }

    # ------------------------------------------------------
    # LOTES
    # ------------------------------------------------------
    @staticmethod
    def lotes(estado="", busqueda="", id_producto=None,
              solo_con_stock=False):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        filtros = ["(l.codigo_lote LIKE %s OR p.nombre LIKE %s "
                   "OR p.codigo LIKE %s)"]
        params = [f"%{busqueda}%"] * 3

        if estado == "VENCIDO":
            filtros.append("l.fecha_vencimiento < CURDATE()")
        elif estado == "POR_VENCER":
            filtros.append("l.fecha_vencimiento BETWEEN CURDATE() "
                           "AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)")
        elif estado in ("CUARENTENA", "LIBERADO", "BLOQUEADO"):
            filtros.append("l.estado_calidad = %s")
            params.append(estado)

        if id_producto:
            filtros.append("l.id_producto = %s")
            params.append(id_producto)

        having = "HAVING stock > 0" if solo_con_stock else ""

        try:
            cursor.execute(f"""
                SELECT
                    l.id_lote_pt, l.codigo_lote, l.fecha_fabricacion,
                    l.fecha_vencimiento, l.estado_calidad,
                    l.cantidad_producida, l.observacion,
                    p.id_producto, p.codigo, p.nombre AS producto,
                    p.precio_referencia,
                    u.simbolo AS unidad,
                    o.id_orden, o.numero AS orden,
                    COALESCE(s.saldo, 0) AS stock,
                    DATEDIFF(l.fecha_vencimiento, CURDATE())
                        AS dias_restantes,
                    DATEDIFF(l.fecha_vencimiento, l.fecha_fabricacion)
                        AS vida_total
                FROM lotes_pt l
                INNER JOIN productos p ON p.id_producto = l.id_producto
                INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
                INNER JOIN ordenes_produccion o ON o.id_orden = l.id_orden
                LEFT JOIN ({SALDOS_SQL}) s
                    ON s.id_lote_pt = l.id_lote_pt
                WHERE {" AND ".join(filtros)}
                {having}
                ORDER BY l.fecha_vencimiento, l.id_lote_pt
            """, params)
            filas = cursor.fetchall()
            for f in filas:
                total = f["vida_total"] or 1
                restante = max(f["dias_restantes"] or 0, 0)
                f["vida_pct"] = max(min(int(restante * 100 / total), 100), 0)
            return filas
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def contar_lotes_por_estado():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT
                    SUM(estado_calidad = 'CUARENTENA') AS cuarentena,
                    SUM(estado_calidad = 'LIBERADO'
                        AND fecha_vencimiento >= CURDATE()) AS liberado,
                    SUM(estado_calidad = 'BLOQUEADO') AS bloqueado,
                    SUM(fecha_vencimiento < CURDATE()) AS vencido,
                    SUM(fecha_vencimiento BETWEEN CURDATE()
                        AND DATE_ADD(CURDATE(), INTERVAL 7 DAY))
                        AS por_vencer,
                    COUNT(*) AS total
                FROM lotes_pt
            """)
            fila = cursor.fetchone() or {}
            return {k: int(v or 0) for k, v in fila.items()}
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def obtener_lote(id_lote):
        filas = ProductoTerminadoModel._lote_por_id(id_lote)
        return filas

    @staticmethod
    def _lote_por_id(id_lote):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute(f"""
                SELECT
                    l.*, p.codigo, p.nombre AS producto,
                    p.precio_referencia, u.simbolo AS unidad,
                    c.nombre AS categoria,
                    o.numero AS orden, o.fecha_inicio, o.fecha_fin,
                    COALESCE(s.saldo, 0) AS stock,
                    DATEDIFF(l.fecha_vencimiento, CURDATE())
                        AS dias_restantes
                FROM lotes_pt l
                INNER JOIN productos p ON p.id_producto = l.id_producto
                INNER JOIN categorias_producto c
                    ON c.id_categoria = p.id_categoria
                INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
                INNER JOIN ordenes_produccion o ON o.id_orden = l.id_orden
                LEFT JOIN ({SALDOS_SQL}) s
                    ON s.id_lote_pt = l.id_lote_pt
                WHERE l.id_lote_pt = %s
            """, (id_lote,))
            return cursor.fetchone()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def cambiar_calidad(id_lote, estado, id_usuario, observacion=""):
        if estado not in ("CUARENTENA", "LIBERADO", "BLOQUEADO"):
            raise ValueError("Estado de calidad no válido.")

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            conexion.start_transaction()
            cursor.execute("""
                SELECT id_lote_pt, estado_calidad, fecha_vencimiento,
                       fecha_vencimiento < CURDATE() AS vencido
                FROM lotes_pt WHERE id_lote_pt = %s FOR UPDATE
            """, (id_lote,))
            lote = cursor.fetchone()
            if not lote:
                raise ValueError("El lote no existe.")
            if lote["estado_calidad"] == estado:
                raise ValueError("El lote ya se encuentra en ese estado.")
            if estado == "LIBERADO" and lote["vencido"]:
                raise ValueError("No se puede liberar un lote vencido.")

            nota = f"[{estado}] {observacion}".strip() if observacion else None
            cursor.execute("""
                UPDATE lotes_pt
                SET estado_calidad = %s,
                    observacion = COALESCE(%s, observacion)
                WHERE id_lote_pt = %s
            """, (estado, nota[:255] if nota else None, id_lote))
            conexion.commit()
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # AJUSTES Y MERMAS
    # ------------------------------------------------------
    @staticmethod
    def registrar_ajuste(id_lote, tipo, cantidad, id_usuario,
                         observacion):
        """
        tipo = MERMA  -> salida (cantidad positiva que se descuenta)
        tipo = AJUSTE_POS / AJUSTE_NEG -> corrección de inventario
        """
        cantidad = q3(cantidad)
        if cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor que cero.")
        if tipo not in ("MERMA", "AJUSTE_POS", "AJUSTE_NEG"):
            raise ValueError("Tipo de movimiento no válido.")
        if not observacion:
            raise ValueError("Indique el motivo del movimiento.")

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            conexion.start_transaction()
            cursor.execute("""
                SELECT id_lote_pt, codigo_lote
                FROM lotes_pt WHERE id_lote_pt = %s FOR UPDATE
            """, (id_lote,))
            lote = cursor.fetchone()
            if not lote:
                raise ValueError("El lote no existe.")

            cursor.execute("""
                SELECT mv.id_almacen, SUM(mv.cantidad_firmada) AS saldo
                FROM movimientos_pt mv
                INNER JOIN almacenes a ON a.id_almacen = mv.id_almacen
                WHERE mv.id_lote_pt = %s AND a.tipo IN ('PT','MIXTO')
                GROUP BY mv.id_almacen
                ORDER BY saldo DESC
                LIMIT 1
            """, (id_lote,))
            fila = cursor.fetchone()
            if not fila:
                raise ValueError("El lote no tiene movimientos.")
            saldo = Decimal(str(fila["saldo"]))

            signo = Decimal("1") if tipo == "AJUSTE_POS" else Decimal("-1")
            if signo < 0 and cantidad > saldo:
                raise ValueError(
                    f"La cantidad supera el stock del lote "
                    f"({saldo.normalize():f})."
                )

            tipo_bd = "MERMA" if tipo == "MERMA" else "AJUSTE"
            cursor.execute("""
                INSERT INTO movimientos_pt
                    (id_lote_pt, id_almacen, cantidad_firmada, tipo,
                     referencia_tipo, referencia_id, id_usuario,
                     observacion)
                VALUES (%s, %s, %s, %s, 'AJUSTE_MANUAL', NULL, %s, %s)
            """, (id_lote, fila["id_almacen"], cantidad * signo,
                  tipo_bd, id_usuario, observacion[:255]))
            conexion.commit()
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # KARDEX
    # ------------------------------------------------------
    @staticmethod
    def kardex(id_lote=None, id_producto=None, tipo="",
               desde=None, hasta=None, limite=500):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        filtros = ["1=1"]
        params = []
        if id_lote:
            filtros.append("mv.id_lote_pt = %s")
            params.append(id_lote)
        if id_producto:
            filtros.append("l.id_producto = %s")
            params.append(id_producto)
        if tipo:
            filtros.append("mv.tipo = %s")
            params.append(tipo)
        if desde:
            filtros.append("DATE(mv.fecha) >= %s")
            params.append(desde)
        if hasta:
            filtros.append("DATE(mv.fecha) <= %s")
            params.append(hasta)

        try:
            cursor.execute(f"""
                SELECT mv.id_movimiento, mv.fecha, mv.tipo,
                       mv.cantidad_firmada, mv.referencia_tipo,
                       mv.referencia_id, mv.observacion,
                       l.id_lote_pt, l.codigo_lote,
                       p.nombre AS producto, p.codigo,
                       un.simbolo AS unidad,
                       a.nombre AS almacen,
                       us.nombre_completo AS usuario
                FROM movimientos_pt mv
                INNER JOIN lotes_pt l ON l.id_lote_pt = mv.id_lote_pt
                INNER JOIN productos p ON p.id_producto = l.id_producto
                INNER JOIN unidades_medida un ON un.id_unidad = p.id_unidad
                INNER JOIN almacenes a ON a.id_almacen = mv.id_almacen
                INNER JOIN usuarios us ON us.id_usuario = mv.id_usuario
                WHERE {" AND ".join(filtros)}
                ORDER BY mv.fecha ASC, mv.id_movimiento ASC
                LIMIT {int(limite)}
            """, params)
            filas = cursor.fetchall()

            # Saldo acumulado por lote
            saldos = {}
            for f in filas:
                clave = f["id_lote_pt"]
                saldos[clave] = saldos.get(clave, Decimal("0")) + \
                    Decimal(str(f["cantidad_firmada"]))
                f["saldo"] = saldos[clave]
            filas.reverse()
            return filas
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # CONFIGURACIÓN
    # ------------------------------------------------------
    @staticmethod
    def actualizar_stock_minimo(id_producto, valor):
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        try:
            cursor.execute("""
                UPDATE productos SET stock_minimo = %s
                WHERE id_producto = %s
            """, (q3(valor), id_producto))
            if cursor.rowcount == 0:
                cursor.execute(
                    "SELECT 1 FROM productos WHERE id_producto=%s",
                    (id_producto,))
                if not cursor.fetchone():
                    raise ValueError("El producto no existe.")
            conexion.commit()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def listar_productos():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT id_producto, codigo, nombre
                FROM productos ORDER BY nombre
            """)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def listar_categorias():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT id_categoria, nombre
                FROM categorias_producto ORDER BY nombre
            """)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()
