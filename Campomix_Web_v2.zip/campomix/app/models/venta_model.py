"""
Módulo de Ventas.

Flujo:
  BORRADOR --(confirmar)--> CONFIRMADA --(entregar)--> ENTREGADA
     |                          |
     +--------(anular)----------+--> CANCELADA

Al CONFIRMAR:
  1. Se valida el stock DISPONIBLE (lotes LIBERADOS y vigentes).
  2. Se asignan lotes por FEFO (primero en vencer, primero en salir).
  3. Se crea el despacho (despachos + despacho_detalles) para la
     trazabilidad lote -> cliente.
  4. Se registran las salidas en movimientos_pt (tipo VENTA).

Al ANULAR una venta confirmada (sin pagos) se devuelve el stock
a los mismos lotes (movimientos_pt tipo DEVOLUCION).
"""

from decimal import Decimal

from app.database.conexion import obtener_conexion
from app.utils import q2, q3


ESTADOS_VALIDOS = ("CONFIRMADA", "PARCIAL", "ENTREGADA")
METODOS_PAGO = ("EFECTIVO", "QR", "TRANSFERENCIA", "TARJETA", "OTRO")


def _estado_pago(total, pagado):
    total = Decimal(str(total or 0))
    pagado = Decimal(str(pagado or 0))
    if total <= 0:
        return "SIN_MONTO"
    if pagado <= 0:
        return "PENDIENTE"
    if pagado < total:
        return "PARCIAL"
    return "PAGADO"


def _siguiente_numero(cursor, tabla, prefijo):
    """Correlativo sin saltos: VEN-000001, VEN-000002..."""
    cursor.execute(f"""
        SELECT COALESCE(MAX(CAST(SUBSTRING(numero, {len(prefijo) + 2})
                        AS UNSIGNED)), 0) + 1 AS n
        FROM {tabla}
        WHERE numero LIKE %s
        FOR UPDATE
    """, (f"{prefijo}-%",))
    return f"{prefijo}-{int(cursor.fetchone()['n']):06d}"


class VentaModel:

    # ------------------------------------------------------
    # LISTADOS
    # ------------------------------------------------------
    @staticmethod
    def listar(busqueda="", estado="", desde=None, hasta=None,
               id_cliente=None, pago=""):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        filtros = ["(v.numero LIKE %s OR c.nombre LIKE %s "
                   "OR c.documento LIKE %s)"]
        params = [f"%{busqueda}%"] * 3
        if estado:
            filtros.append("v.estado = %s")
            params.append(estado)
        if desde:
            filtros.append("DATE(v.fecha) >= %s")
            params.append(desde)
        if hasta:
            filtros.append("DATE(v.fecha) <= %s")
            params.append(hasta)
        if id_cliente:
            filtros.append("v.id_cliente = %s")
            params.append(id_cliente)

        try:
            cursor.execute(f"""
                SELECT v.id_venta, v.numero, v.fecha, v.estado,
                       v.subtotal, v.descuento_total, v.total,
                       v.fecha_confirmacion,
                       c.id_cliente, c.nombre AS cliente,
                       c.documento, c.tipo_cliente,
                       u.nombre_completo AS vendedor,
                       COALESCE(pg.pagado, 0) AS pagado,
                       (SELECT COUNT(*) FROM venta_detalles d
                        WHERE d.id_venta = v.id_venta) AS num_items
                FROM ventas v
                INNER JOIN clientes c ON c.id_cliente = v.id_cliente
                INNER JOIN usuarios u ON u.id_usuario = v.id_usuario
                LEFT JOIN (
                    SELECT id_venta, SUM(monto) AS pagado
                    FROM pagos_venta GROUP BY id_venta
                ) pg ON pg.id_venta = v.id_venta
                WHERE {" AND ".join(filtros)}
                ORDER BY v.fecha DESC, v.id_venta DESC
            """, params)
            filas = cursor.fetchall()
            for f in filas:
                f["saldo"] = Decimal(str(f["total"])) - \
                    Decimal(str(f["pagado"]))
                f["estado_pago"] = _estado_pago(f["total"], f["pagado"])

            if pago:
                filas = [f for f in filas
                         if f["estado_pago"] == pago
                         and f["estado"] in ESTADOS_VALIDOS]
            return filas
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def resumen():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT
                    COALESCE(SUM(CASE WHEN DATE(fecha) = CURDATE()
                        THEN total END), 0) AS hoy,
                    COALESCE(SUM(CASE
                        WHEN YEAR(fecha) = YEAR(CURDATE())
                         AND MONTH(fecha) = MONTH(CURDATE())
                        THEN total END), 0) AS mes,
                    COALESCE(SUM(CASE
                        WHEN YEAR(fecha) = YEAR(CURDATE())
                         AND MONTH(fecha) = MONTH(CURDATE())
                        THEN 1 END), 0) AS ventas_mes,
                    COALESCE(SUM(total), 0) AS total_historico
                FROM ventas
                WHERE estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """)
            datos = cursor.fetchone()

            cursor.execute("""
                SELECT COALESCE(SUM(p.monto), 0) AS cobrado
                FROM pagos_venta p
                INNER JOIN ventas v ON v.id_venta = p.id_venta
                WHERE v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """)
            datos["cobrado"] = cursor.fetchone()["cobrado"]
            datos["por_cobrar"] = (datos["total_historico"]
                                   - datos["cobrado"])

            cursor.execute("""
                SELECT COUNT(*) AS n FROM ventas WHERE estado = 'BORRADOR'
            """)
            datos["borradores"] = cursor.fetchone()["n"]
            datos["ticket_promedio"] = (
                datos["mes"] / datos["ventas_mes"]
                if datos["ventas_mes"] else Decimal("0")
            )
            return datos
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # PRODUCTOS DISPONIBLES PARA VENDER
    # ------------------------------------------------------
    @staticmethod
    def productos_para_venta():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT p.id_producto, p.codigo, p.nombre,
                       p.precio_referencia, u.simbolo AS unidad,
                       c.nombre AS categoria,
                       COALESCE(SUM(CASE
                           WHEN l.estado_calidad = 'LIBERADO'
                            AND l.fecha_vencimiento >= CURDATE()
                           THEN s.saldo END), 0) AS disponible
                FROM productos p
                INNER JOIN categorias_producto c
                    ON c.id_categoria = p.id_categoria
                INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
                LEFT JOIN lotes_pt l ON l.id_producto = p.id_producto
                LEFT JOIN (
                    SELECT mv.id_lote_pt, SUM(mv.cantidad_firmada) AS saldo
                    FROM movimientos_pt mv
                    INNER JOIN almacenes a ON a.id_almacen = mv.id_almacen
                       AND a.tipo IN ('PT','MIXTO')
                    GROUP BY mv.id_lote_pt
                ) s ON s.id_lote_pt = l.id_lote_pt
                WHERE p.activo = 1 AND c.activo = 1
                GROUP BY p.id_producto, p.codigo, p.nombre,
                         p.precio_referencia, u.simbolo, c.nombre
                ORDER BY p.nombre
            """)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # OBTENER VENTA COMPLETA
    # ------------------------------------------------------
    @staticmethod
    def obtener(id_venta):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT v.*, c.nombre AS cliente, c.documento,
                       c.telefono, c.correo, c.direccion,
                       c.tipo_cliente,
                       u.nombre_completo AS vendedor
                FROM ventas v
                INNER JOIN clientes c ON c.id_cliente = v.id_cliente
                INNER JOIN usuarios u ON u.id_usuario = v.id_usuario
                WHERE v.id_venta = %s
            """, (id_venta,))
            venta = cursor.fetchone()
            if not venta:
                return None

            cursor.execute("""
                SELECT d.*, p.codigo, p.nombre AS producto,
                       un.simbolo AS unidad,
                       (d.cantidad * d.precio_unitario) AS bruto,
                       (d.cantidad * d.precio_unitario - d.descuento)
                           AS importe
                FROM venta_detalles d
                INNER JOIN productos p ON p.id_producto = d.id_producto
                INNER JOIN unidades_medida un ON un.id_unidad = p.id_unidad
                WHERE d.id_venta = %s
                ORDER BY d.id_detalle
            """, (id_venta,))
            venta["detalles"] = cursor.fetchall()

            cursor.execute("""
                SELECT p.*, u.nombre_completo AS usuario
                FROM pagos_venta p
                INNER JOIN usuarios u ON u.id_usuario = p.id_usuario
                WHERE p.id_venta = %s
                ORDER BY p.fecha
            """, (id_venta,))
            venta["pagos"] = cursor.fetchall()

            cursor.execute("""
                SELECT ds.numero AS despacho, ds.estado AS estado_despacho,
                       dd.cantidad, l.id_lote_pt, l.codigo_lote,
                       l.fecha_vencimiento, p.nombre AS producto,
                       un.simbolo AS unidad
                FROM despachos ds
                INNER JOIN despacho_detalles dd
                    ON dd.id_despacho = ds.id_despacho
                INNER JOIN lotes_pt l ON l.id_lote_pt = dd.id_lote_pt
                INNER JOIN productos p ON p.id_producto = l.id_producto
                INNER JOIN unidades_medida un ON un.id_unidad = p.id_unidad
                WHERE ds.id_venta = %s
                ORDER BY dd.id_detalle
            """, (id_venta,))
            venta["lotes"] = cursor.fetchall()

            pagado = sum((Decimal(str(p["monto"])) for p in venta["pagos"]),
                         Decimal("0"))
            venta["pagado"] = pagado
            venta["saldo"] = Decimal(str(venta["total"])) - pagado
            venta["estado_pago"] = _estado_pago(venta["total"], pagado)
            return venta
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # GUARDAR (crear o editar borrador)
    # ------------------------------------------------------
    @staticmethod
    def _calcular_totales(items):
        subtotal = Decimal("0")
        descuento = Decimal("0")
        for it in items:
            bruto = q2(it["cantidad"] * it["precio_unitario"])
            if it["descuento"] > bruto:
                raise ValueError(
                    "El descuento de una línea no puede superar su importe."
                )
            subtotal += bruto
            descuento += it["descuento"]
        return q2(subtotal), q2(descuento), q2(subtotal - descuento)

    @staticmethod
    def guardar(id_cliente, items, observacion, id_usuario,
                confirmar=False, id_venta=None):
        if not items:
            raise ValueError("Agregue al menos un producto a la venta.")

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            conexion.start_transaction()

            cursor.execute("""
                SELECT id_cliente FROM clientes
                WHERE id_cliente = %s AND activo = 1
            """, (id_cliente,))
            if not cursor.fetchone():
                raise ValueError("Seleccione un cliente activo.")

            ids = list({it["id_producto"] for it in items})
            marcas = ", ".join(["%s"] * len(ids))
            cursor.execute(f"""
                SELECT p.id_producto FROM productos p
                INNER JOIN categorias_producto c
                    ON c.id_categoria = p.id_categoria
                WHERE p.activo = 1 AND c.activo = 1
                  AND p.id_producto IN ({marcas})
            """, ids)
            if len(cursor.fetchall()) != len(ids):
                raise ValueError(
                    "Uno de los productos no existe o está inactivo."
                )

            subtotal, descuento, total = VentaModel._calcular_totales(items)

            if id_venta is None:
                cursor.execute("""
                    INSERT INTO ventas
                        (numero, id_cliente, estado, subtotal,
                         descuento_total, total, id_usuario, observacion)
                    VALUES (REPLACE(UUID(), '-', ''), %s, 'BORRADOR', %s, %s, %s, %s, %s)
                """, (id_cliente, subtotal, descuento, total,
                      id_usuario, observacion or None))
                id_venta = cursor.lastrowid
                cursor.execute("""
                    UPDATE ventas SET numero = %s WHERE id_venta = %s
                """, (_siguiente_numero(cursor, "ventas", "VEN"), id_venta))
            else:
                cursor.execute("""
                    SELECT estado FROM ventas
                    WHERE id_venta = %s FOR UPDATE
                """, (id_venta,))
                fila = cursor.fetchone()
                if not fila:
                    raise ValueError("La venta no existe.")
                if fila["estado"] != "BORRADOR":
                    raise ValueError(
                        "Solo se pueden editar ventas en BORRADOR."
                    )
                cursor.execute("""
                    UPDATE ventas
                    SET id_cliente = %s, subtotal = %s,
                        descuento_total = %s, total = %s,
                        observacion = %s
                    WHERE id_venta = %s
                """, (id_cliente, subtotal, descuento, total,
                      observacion or None, id_venta))
                cursor.execute(
                    "DELETE FROM venta_detalles WHERE id_venta = %s",
                    (id_venta,))

            for it in items:
                cursor.execute("""
                    INSERT INTO venta_detalles
                        (id_venta, id_producto, cantidad,
                         precio_unitario, descuento)
                    VALUES (%s, %s, %s, %s, %s)
                """, (id_venta, it["id_producto"], it["cantidad"],
                      it["precio_unitario"], it["descuento"]))

            if confirmar:
                VentaModel._confirmar(cursor, id_venta, id_usuario)

            conexion.commit()
            return id_venta
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # CONFIRMAR (descuenta stock FEFO y crea despacho)
    # ------------------------------------------------------
    @staticmethod
    def confirmar(id_venta, id_usuario):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            conexion.start_transaction()
            VentaModel._confirmar(cursor, id_venta, id_usuario)
            conexion.commit()
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def _confirmar(cursor, id_venta, id_usuario):
        cursor.execute("""
            SELECT v.id_venta, v.numero, v.estado, c.activo
            FROM ventas v
            INNER JOIN clientes c ON c.id_cliente = v.id_cliente
            WHERE v.id_venta = %s FOR UPDATE
        """, (id_venta,))
        venta = cursor.fetchone()
        if not venta:
            raise ValueError("La venta no existe.")
        if venta["estado"] != "BORRADOR":
            raise ValueError("Solo se pueden confirmar ventas en BORRADOR.")
        if not venta["activo"]:
            raise ValueError("El cliente de esta venta está inactivo.")

        cursor.execute("""
            SELECT d.id_detalle, d.id_producto, d.cantidad, p.nombre,
                   u.simbolo
            FROM venta_detalles d
            INNER JOIN productos p ON p.id_producto = d.id_producto
            INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
            WHERE d.id_venta = %s
            ORDER BY d.id_detalle
        """, (id_venta,))
        detalles = cursor.fetchall()
        if not detalles:
            raise ValueError("La venta no tiene productos.")

        # Lotes disponibles por producto (bloqueados para la transacción)
        disponibles = {}
        for id_producto in {d["id_producto"] for d in detalles}:
            cursor.execute("""
                SELECT id_lote_pt FROM lotes_pt
                WHERE id_producto = %s FOR UPDATE
            """, (id_producto,))
            cursor.fetchall()

            cursor.execute("""
                SELECT l.id_lote_pt, l.codigo_lote, mv.id_almacen,
                       SUM(mv.cantidad_firmada) AS saldo
                FROM lotes_pt l
                INNER JOIN movimientos_pt mv ON mv.id_lote_pt = l.id_lote_pt
                INNER JOIN almacenes a ON a.id_almacen = mv.id_almacen
                   AND a.tipo IN ('PT','MIXTO')
                WHERE l.id_producto = %s
                  AND l.estado_calidad = 'LIBERADO'
                  AND l.fecha_vencimiento >= CURDATE()
                GROUP BY l.id_lote_pt, l.codigo_lote, mv.id_almacen,
                         l.fecha_vencimiento, l.fecha_fabricacion
                HAVING saldo > 0
                ORDER BY l.fecha_vencimiento, l.fecha_fabricacion,
                         l.id_lote_pt
            """, (id_producto,))
            disponibles[id_producto] = [
                {**f, "saldo": Decimal(str(f["saldo"]))}
                for f in cursor.fetchall()
            ]

        # Validar stock total por producto
        requerido = {}
        for d in detalles:
            requerido[d["id_producto"]] = requerido.get(
                d["id_producto"], Decimal("0")) + Decimal(str(d["cantidad"]))

        faltantes = []
        for d in detalles:
            pid = d["id_producto"]
            if pid not in requerido:
                continue
            stock = sum((l["saldo"] for l in disponibles[pid]), Decimal("0"))
            if stock < requerido[pid]:
                faltantes.append(
                    f"{d['nombre']}: disponible "
                    f"{q3(stock).normalize():f} {d['simbolo']}, "
                    f"requerido {q3(requerido[pid]).normalize():f}"
                )
            requerido.pop(pid)
        if faltantes:
            raise ValueError(
                "Stock disponible insuficiente (solo lotes LIBERADOS y "
                "vigentes). " + " | ".join(faltantes)
            )

        # Crear despacho
        cursor.execute("""
            INSERT INTO despachos (numero, id_venta, estado, id_usuario)
            VALUES (REPLACE(UUID(), '-', ''), %s, 'CONFIRMADO', %s)
        """, (id_venta, id_usuario))
        id_despacho = cursor.lastrowid
        numero_despacho = _siguiente_numero(cursor, "despachos", "DES")
        cursor.execute("""
            UPDATE despachos SET numero = %s WHERE id_despacho = %s
        """, (numero_despacho, id_despacho))

        # Asignar FEFO
        for d in detalles:
            pendiente = Decimal(str(d["cantidad"]))
            for lote in disponibles[d["id_producto"]]:
                if pendiente <= 0:
                    break
                if lote["saldo"] <= 0:
                    continue
                tomar = min(lote["saldo"], pendiente)
                lote["saldo"] -= tomar
                pendiente -= tomar

                cursor.execute("""
                    INSERT INTO despacho_detalles
                        (id_despacho, id_venta_detalle, id_lote_pt,
                         id_almacen, cantidad)
                    VALUES (%s, %s, %s, %s, %s)
                """, (id_despacho, d["id_detalle"], lote["id_lote_pt"],
                      lote["id_almacen"], tomar))

                cursor.execute("""
                    INSERT INTO movimientos_pt
                        (id_lote_pt, id_almacen, cantidad_firmada, tipo,
                         referencia_tipo, referencia_id, id_usuario,
                         observacion)
                    VALUES (%s, %s, %s, 'VENTA', 'DESPACHO', %s, %s, %s)
                """, (lote["id_lote_pt"], lote["id_almacen"], -tomar,
                      id_despacho, id_usuario,
                      f"Venta {venta['numero']} / {numero_despacho}"))

        cursor.execute("""
            UPDATE ventas
            SET estado = 'CONFIRMADA', fecha_confirmacion = NOW()
            WHERE id_venta = %s
        """, (id_venta,))

    # ------------------------------------------------------
    # ENTREGAR
    # ------------------------------------------------------
    @staticmethod
    def entregar(id_venta):
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        try:
            cursor.execute("""
                UPDATE ventas SET estado = 'ENTREGADA'
                WHERE id_venta = %s AND estado = 'CONFIRMADA'
            """, (id_venta,))
            if cursor.rowcount == 0:
                raise ValueError(
                    "Solo se pueden entregar ventas CONFIRMADAS."
                )
            conexion.commit()
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # ANULAR
    # ------------------------------------------------------
    @staticmethod
    def anular(id_venta, id_usuario, motivo):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            conexion.start_transaction()
            cursor.execute("""
                SELECT id_venta, numero, estado FROM ventas
                WHERE id_venta = %s FOR UPDATE
            """, (id_venta,))
            venta = cursor.fetchone()
            if not venta:
                raise ValueError("La venta no existe.")
            if venta["estado"] not in ("BORRADOR", "CONFIRMADA"):
                raise ValueError(
                    "Solo se pueden anular ventas en BORRADOR o "
                    "CONFIRMADAS (no entregadas)."
                )

            cursor.execute("""
                SELECT COUNT(*) AS n FROM pagos_venta WHERE id_venta = %s
            """, (id_venta,))
            if cursor.fetchone()["n"] > 0:
                raise ValueError(
                    "La venta tiene pagos registrados y no puede anularse."
                )

            if venta["estado"] == "CONFIRMADA":
                cursor.execute("""
                    SELECT ds.id_despacho, dd.id_lote_pt, dd.id_almacen,
                           dd.cantidad
                    FROM despachos ds
                    INNER JOIN despacho_detalles dd
                        ON dd.id_despacho = ds.id_despacho
                    WHERE ds.id_venta = %s AND ds.estado = 'CONFIRMADO'
                """, (id_venta,))
                for fila in cursor.fetchall():
                    cursor.execute("""
                        INSERT INTO movimientos_pt
                            (id_lote_pt, id_almacen, cantidad_firmada,
                             tipo, referencia_tipo, referencia_id,
                             id_usuario, observacion)
                        VALUES (%s, %s, %s, 'DEVOLUCION',
                                'ANULACION_VENTA', %s, %s, %s)
                    """, (fila["id_lote_pt"], fila["id_almacen"],
                          fila["cantidad"], id_venta, id_usuario,
                          f"Reingreso por anulación de {venta['numero']}"))

                cursor.execute("""
                    UPDATE despachos SET estado = 'ANULADO'
                    WHERE id_venta = %s
                """, (id_venta,))

            cursor.execute("""
                UPDATE ventas
                SET estado = 'CANCELADA',
                    observacion = CONCAT_WS('\n', NULLIF(observacion, ''),
                                            %s)
                WHERE id_venta = %s
            """, (f"ANULADA: {motivo}", id_venta))
            conexion.commit()
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    # ------------------------------------------------------
    # PAGOS
    # ------------------------------------------------------
    @staticmethod
    def registrar_pago(id_venta, monto, metodo, referencia, id_usuario):
        if metodo not in METODOS_PAGO:
            raise ValueError("Seleccione un método de pago válido.")
        monto = q2(monto)
        if monto <= 0:
            raise ValueError("El monto debe ser mayor que cero.")

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            conexion.start_transaction()
            cursor.execute("""
                SELECT estado, total FROM ventas
                WHERE id_venta = %s FOR UPDATE
            """, (id_venta,))
            venta = cursor.fetchone()
            if not venta:
                raise ValueError("La venta no existe.")
            if venta["estado"] not in ESTADOS_VALIDOS:
                raise ValueError(
                    "Solo se registran pagos en ventas confirmadas."
                )
            cursor.execute("""
                SELECT COALESCE(SUM(monto), 0) AS pagado
                FROM pagos_venta WHERE id_venta = %s
            """, (id_venta,))
            saldo = Decimal(str(venta["total"])) - \
                Decimal(str(cursor.fetchone()["pagado"]))
            if saldo <= 0:
                raise ValueError("La venta ya está totalmente pagada.")
            if monto > saldo:
                raise ValueError(
                    f"El monto supera el saldo pendiente (Bs {saldo:.2f})."
                )
            cursor.execute("""
                INSERT INTO pagos_venta
                    (id_venta, monto, metodo, referencia, id_usuario)
                VALUES (%s, %s, %s, %s, %s)
            """, (id_venta, monto, metodo, referencia or None, id_usuario))
            conexion.commit()
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()
