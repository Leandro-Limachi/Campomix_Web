
from decimal import Decimal

from app.database.conexion import obtener_conexion


class OrdenProduccionModel:

    @staticmethod
    def listar():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    o.id_orden,
                    o.numero,
                    o.cantidad_planificada,
                    o.cantidad_obtenida,
                    o.fecha_inicio,
                    o.fecha_fin,
                    o.estado,
                    o.observacion,
                    p.codigo AS codigo_producto,
                    p.nombre AS producto,
                    u.simbolo AS unidad

                FROM ordenes_produccion o

                INNER JOIN recetas r
                    ON o.id_receta = r.id_receta

                INNER JOIN productos p
                    ON r.id_producto = p.id_producto

                INNER JOIN unidades_medida u
                    ON p.id_unidad = u.id_unidad

                ORDER BY o.id_orden DESC
            """)

            return cursor.fetchall()

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def listar_recetas_vigentes():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    r.id_receta,
                    r.cantidad_base,
                    p.id_producto,
                    p.codigo,
                    p.nombre AS producto,
                    u.simbolo AS unidad

                FROM recetas r

                INNER JOIN productos p
                    ON r.id_producto = p.id_producto

                INNER JOIN categorias_producto c
                    ON p.id_categoria = c.id_categoria

                INNER JOIN unidades_medida u
                    ON p.id_unidad = u.id_unidad

                WHERE r.estado = 'VIGENTE'
                  AND p.activo = 1
                  AND c.activo = 1

                ORDER BY p.nombre
            """)

            return cursor.fetchall()

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def obtener_receta(id_receta):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    r.id_receta,
                    r.cantidad_base,
                    r.estado,
                    p.id_producto,
                    p.nombre AS producto,
                    u.simbolo AS unidad

                FROM recetas r

                INNER JOIN productos p
                    ON r.id_producto = p.id_producto

                INNER JOIN unidades_medida u
                    ON p.id_unidad = u.id_unidad

                WHERE r.id_receta = %s
            """, (id_receta,))

            return cursor.fetchone()

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def calcular_ingredientes(id_receta, cantidad_planificada):
        receta = OrdenProduccionModel.obtener_receta(id_receta)

        if not receta:
            raise ValueError("La receta no existe.")

        cantidad_planificada = Decimal(
            str(cantidad_planificada)
        )

        cantidad_base = Decimal(
            str(receta["cantidad_base"])
        )

        if cantidad_planificada <= 0:
            raise ValueError(
                "La cantidad planificada debe ser mayor que cero."
            )

        if cantidad_base <= 0:
            raise ValueError(
                "El rendimiento base de la receta no es válido."
            )

        factor = cantidad_planificada / cantidad_base

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    d.id_materia,
                    m.codigo,
                    m.nombre AS materia_prima,
                    d.cantidad,
                    u.simbolo AS unidad

                FROM receta_detalles d

                INNER JOIN materias_primas m
                    ON d.id_materia = m.id_materia

                INNER JOIN unidades_medida u
                    ON m.id_unidad = u.id_unidad

                WHERE d.id_receta = %s

                ORDER BY m.nombre
            """, (id_receta,))

            ingredientes = cursor.fetchall()

            resultado = []

            for ingrediente in ingredientes:

                cantidad_base_ingrediente = Decimal(
                    str(ingrediente["cantidad"])
                )

                cantidad_necesaria = (
                    cantidad_base_ingrediente * factor
                )

                resultado.append({
                    "id_materia": ingrediente["id_materia"],
                    "codigo": ingrediente["codigo"],
                    "materia_prima": ingrediente["materia_prima"],
                    "unidad": ingrediente["unidad"],
                    "cantidad_base": cantidad_base_ingrediente,
                    "cantidad_necesaria": cantidad_necesaria
                })

            return {
                "receta": receta,
                "cantidad_planificada": cantidad_planificada,
                "factor": factor,
                "ingredientes": resultado
            }

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def crear(id_receta, cantidad_planificada,
              id_usuario, observacion=""):

        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            conexion.start_transaction()

            cursor.execute("""
                SELECT
                    r.id_receta,
                    r.cantidad_base,
                    r.estado,
                    p.activo AS producto_activo,
                    c.activo AS categoria_activa

                FROM recetas r

                INNER JOIN productos p
                    ON r.id_producto = p.id_producto

                INNER JOIN categorias_producto c
                    ON p.id_categoria = c.id_categoria

                WHERE r.id_receta = %s

                FOR UPDATE
            """, (id_receta,))

            receta = cursor.fetchone()

            if not receta:
                raise ValueError("La receta no existe.")

            if receta["estado"] != "VIGENTE":
                raise ValueError(
                    "Solo se pueden utilizar recetas vigentes."
                )

            if (
                not receta["producto_activo"]
                or not receta["categoria_activa"]
            ):
                raise ValueError(
                    "El producto y su categoría deben estar activos."
                )

            cantidad = Decimal(str(cantidad_planificada))

            if (
                not cantidad.is_finite()
                or cantidad <= 0
                or cantidad > Decimal("999999999999999.999")
                or cantidad.as_tuple().exponent < -3
            ):
                raise ValueError(
                    "La cantidad planificada debe ser positiva "
                    "y tener máximo 3 decimales."
                )

            cursor.execute("""
                SELECT COUNT(*) AS total
                FROM receta_detalles
                WHERE id_receta = %s
            """, (id_receta,))

            if cursor.fetchone()["total"] == 0:
                raise ValueError(
                    "La receta no tiene ingredientes registrados."
                )

            # Se genera un identificador único provisional.
            # No se descuenta inventario en esta etapa.
            import uuid

            numero = "OP-" + uuid.uuid4().hex[:12].upper()

            cursor.execute("""
                INSERT INTO ordenes_produccion
                (
                    numero,
                    id_receta,
                    cantidad_planificada,
                    estado,
                    id_usuario,
                    observacion
                )
                VALUES (
                    %s, %s, %s,
                    'PLANIFICADA', %s, %s
                )
            """, (
                numero,
                id_receta,
                cantidad,
                id_usuario,
                observacion
            ))

            id_orden = cursor.lastrowid

            conexion.commit()

            return id_orden

        except Exception:
            conexion.rollback()
            raise

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def obtener(id_orden):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT
                    o.*,
                    p.nombre AS producto,
                    p.codigo AS codigo_producto,
                    u.simbolo AS unidad

                FROM ordenes_produccion o

                INNER JOIN recetas r
                    ON o.id_receta = r.id_receta

                INNER JOIN productos p
                    ON r.id_producto = p.id_producto

                INNER JOIN unidades_medida u
                    ON p.id_unidad = u.id_unidad

                WHERE o.id_orden = %s
            """, (id_orden,))

            return cursor.fetchone()

        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def vida_util_producto(id_orden):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        try:
            cursor.execute("""
                SELECT p.vida_util_dias
                FROM ordenes_produccion o
                INNER JOIN recetas r ON o.id_receta = r.id_receta
                INNER JOIN productos p ON r.id_producto = p.id_producto
                WHERE o.id_orden = %s
            """, (id_orden,))
            fila = cursor.fetchone()
            return fila["vida_util_dias"] if fila else None

        finally:
            cursor.close()
            conexion.close()
