from app.database.conexion import obtener_conexion


TIPOS_CLIENTE = ("MINORISTA", "MAYORISTA", "DISTRIBUIDOR", "INSTITUCIONAL")


class ClienteModel:

    @staticmethod
    def listar(busqueda="", tipo="", estado=""):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)

        filtros = ["(c.nombre LIKE %s OR c.documento LIKE %s "
                   "OR c.telefono LIKE %s OR c.correo LIKE %s)"]
        params = [f"%{busqueda}%"] * 4
        if tipo in TIPOS_CLIENTE:
            filtros.append("c.tipo_cliente = %s")
            params.append(tipo)
        if estado == "activos":
            filtros.append("c.activo = 1")
        elif estado == "inactivos":
            filtros.append("c.activo = 0")

        try:
            cursor.execute(f"""
                SELECT c.*,
                       COALESCE(v.num_ventas, 0) AS num_ventas,
                       COALESCE(v.total_comprado, 0) AS total_comprado,
                       COALESCE(v.total_comprado, 0)
                         - COALESCE(pg.pagado, 0) AS saldo,
                       v.ultima_compra
                FROM clientes c
                LEFT JOIN (
                    SELECT id_cliente, COUNT(*) AS num_ventas,
                           SUM(total) AS total_comprado,
                           MAX(fecha) AS ultima_compra
                    FROM ventas
                    WHERE estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
                    GROUP BY id_cliente
                ) v ON v.id_cliente = c.id_cliente
                LEFT JOIN (
                    SELECT ve.id_cliente, SUM(p.monto) AS pagado
                    FROM pagos_venta p
                    INNER JOIN ventas ve ON ve.id_venta = p.id_venta
                    WHERE ve.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
                    GROUP BY ve.id_cliente
                ) pg ON pg.id_cliente = c.id_cliente
                WHERE {" AND ".join(filtros)}
                ORDER BY c.activo DESC, c.nombre
            """, params)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def resumen():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT COUNT(*) AS total,
                       COALESCE(SUM(activo = 1), 0) AS activos,
                       COALESCE(SUM(MONTH(creado_en) = MONTH(CURDATE())
                           AND YEAR(creado_en) = YEAR(CURDATE())), 0)
                           AS nuevos_mes
                FROM clientes
            """)
            datos = cursor.fetchone()
            cursor.execute("""
                SELECT COUNT(DISTINCT id_cliente) AS con_compras
                FROM ventas
                WHERE estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """)
            datos.update(cursor.fetchone())
            return datos
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def listar_activos():
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT id_cliente, nombre, documento, tipo_cliente,
                       telefono, direccion
                FROM clientes WHERE activo = 1 ORDER BY nombre
            """)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def obtener(id_cliente):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute(
                "SELECT * FROM clientes WHERE id_cliente = %s",
                (id_cliente,))
            return cursor.fetchone()
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def existe_documento(documento, excluir_id=None):
        if not documento:
            return False
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        try:
            sql = "SELECT 1 FROM clientes WHERE documento = %s"
            params = [documento]
            if excluir_id:
                sql += " AND id_cliente <> %s"
                params.append(excluir_id)
            cursor.execute(sql + " LIMIT 1", params)
            return cursor.fetchone() is not None
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def crear(d):
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        try:
            cursor.execute("""
                INSERT INTO clientes
                    (nombre, tipo_cliente, documento, telefono, correo,
                     direccion, observacion, activo)
                VALUES (%s, %s, %s, %s, %s, %s, %s, 1)
            """, (d["nombre"], d["tipo_cliente"], d["documento"] or None,
                  d["telefono"] or None, d["correo"] or None,
                  d["direccion"] or None, d["observacion"] or None))
            conexion.commit()
            return cursor.lastrowid
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def actualizar(id_cliente, d):
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        try:
            cursor.execute("""
                UPDATE clientes
                SET nombre = %s, tipo_cliente = %s, documento = %s,
                    telefono = %s, correo = %s, direccion = %s,
                    observacion = %s
                WHERE id_cliente = %s
            """, (d["nombre"], d["tipo_cliente"], d["documento"] or None,
                  d["telefono"] or None, d["correo"] or None,
                  d["direccion"] or None, d["observacion"] or None,
                  id_cliente))
            conexion.commit()
        except Exception:
            conexion.rollback()
            raise
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def cambiar_estado(id_cliente):
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        try:
            cursor.execute("""
                UPDATE clientes SET activo = 1 - activo
                WHERE id_cliente = %s
            """, (id_cliente,))
            conexion.commit()
            return cursor.rowcount
        finally:
            cursor.close()
            conexion.close()

    @staticmethod
    def estadisticas(id_cliente):
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        try:
            cursor.execute("""
                SELECT COUNT(*) AS num_ventas,
                       COALESCE(SUM(v.total), 0) AS total_comprado,
                       COALESCE(AVG(v.total), 0) AS ticket_promedio,
                       MAX(v.fecha) AS ultima_compra,
                       MIN(v.fecha) AS primera_compra
                FROM ventas v
                WHERE v.id_cliente = %s
                  AND v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """, (id_cliente,))
            datos = cursor.fetchone()
            cursor.execute("""
                SELECT COALESCE(SUM(p.monto), 0) AS pagado
                FROM pagos_venta p
                INNER JOIN ventas v ON v.id_venta = p.id_venta
                WHERE v.id_cliente = %s
                  AND v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
            """, (id_cliente,))
            datos["pagado"] = cursor.fetchone()["pagado"]
            datos["saldo"] = datos["total_comprado"] - datos["pagado"]

            cursor.execute("""
                SELECT p.nombre, u.simbolo AS unidad,
                       SUM(d.cantidad) AS cantidad,
                       SUM(d.cantidad * d.precio_unitario - d.descuento)
                           AS importe
                FROM venta_detalles d
                INNER JOIN ventas v ON v.id_venta = d.id_venta
                INNER JOIN productos p ON p.id_producto = d.id_producto
                INNER JOIN unidades_medida u ON u.id_unidad = p.id_unidad
                WHERE v.id_cliente = %s
                  AND v.estado IN ('CONFIRMADA','PARCIAL','ENTREGADA')
                GROUP BY p.id_producto, p.nombre, u.simbolo
                ORDER BY importe DESC
                LIMIT 5
            """, (id_cliente,))
            datos["top_productos"] = cursor.fetchall()
            return datos
        finally:
            cursor.close()
            conexion.close()
