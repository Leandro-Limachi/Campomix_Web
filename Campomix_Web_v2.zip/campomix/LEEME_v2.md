# CAMPOMIX v2.0: Sistema de Gestión de Productos Lácteos

## Qué hay de nuevo

| Módulo | Qué hace |
|---|---|
| **Ejecución de producción** | Las órdenes ahora se **inician** (descuentan materia prima por FEFO), se **finalizan** (generan el lote de producto terminado) y se **cancelan** (devuelven la MP a sus lotes). |
| **Almacén de Productos Terminados** | Inventario por producto: disponible, cuarentena, bloqueado, vencido, valorizado y stock mínimo con alertas. |
| **Lotes y calidad PT** | Liberar, bloquear o devolver a cuarentena; barra de vida útil; mermas y ajustes; trazabilidad completa por lote. |
| **Kárdex PT** | Historial de entradas y salidas con saldo, filtros por producto, tipo y fechas. Se puede imprimir. |
| **Clientes** | Registro con validaciones (CI/NIT único, correo, teléfono), tipos de cliente, ficha con historial, total comprado y saldo. |
| **Ventas** | Punto de venta con carrito, borradores, confirmación con **despacho FEFO**, entrega, **cobros** parciales o totales (Efectivo/QR/Transferencia/Tarjeta), anulación con devolución de stock y **nota de venta** imprimible. |
| **Panel principal** | KPIs reales, gráfico de ventas de 14 días, ventas por categoría, top de productos y alertas automáticas. |
| **Diseño** | Nueva interfaz: menú agrupado con contadores, notificaciones animadas, login renovado, páginas 404/500. **Funciona sin internet** (librerías incluidas en `static/vendor`). |

## Instalación

### 1. Base de datos (elija UNA opción)

- **Opción A: conservar sus datos actuales (recomendada).** En MySQL Workbench abra y ejecute
  `database/actualizacion_v2_modulos_comerciales.sql`. Solo agrega columnas, índices, una vista y 5 clientes de ejemplo.
  **Ejecútelo una sola vez.**
- **Opción B: instalación limpia.** Ejecute `database/campomix_db_completa_v2.sql`. Esto **borra y recrea** todas las tablas.

### 2. Aplicación

```bash
# dentro de la carpeta campomix
.venv\Scripts\activate          # o cree uno: python -m venv .venv
pip install -r requirements.txt
python run.py
```

Abra http://127.0.0.1:5000 e ingrese con su usuario administrador.
El archivo `.env` se mantiene igual que antes (host, usuario y contraseña de MySQL).

## Flujo de demostración (para la presentación)

1. **Calidad de MP** → apruebe los lotes de materia prima en cuarentena.
2. **Órdenes de producción** → *Nueva orden* (p. ej. Yogurt de Mango) → **Iniciar producción**.
   Muestre la tabla «Consumo real por lote (FEFO)».
3. **Finalizar producción** → indique la cantidad obtenida. Se crea el lote `PT-…` en **CUARENTENA**.
4. **Lotes y calidad PT** → **Liberar** el lote. Ya aparece como disponible en **Almacén PT**.
5. **Nueva venta** → elija un cliente, agregue productos desde el catálogo y **Confirmar venta**.
   Muestre el despacho con el lote asignado.
6. En el detalle de la venta: **Registrar pago** parcial y luego el saldo → **Marcar entregada** → **Nota de venta**.
7. Vuelva al **Panel principal**: el gráfico, los KPIs y las alertas ya reflejan todo.

**Validaciones para mostrar:** intente vender más del stock disponible, vender un lote en cuarentena,
pagar más del saldo o anular una venta con pagos. El sistema lo impide con un mensaje claro.

## Reglas de negocio implementadas

- El stock **nunca se edita a mano**: se calcula sumando el kárdex (`movimientos_mp` / `movimientos_pt`).
- Solo se consume MP **APROBADA y vigente**, y solo se vende PT **LIBERADO y vigente**.
- **FEFO** (First Expired, First Out): primero sale lo que vence antes, tanto en producción como en ventas.
- Todas las operaciones de inventario usan **transacciones** con bloqueo de filas (`SELECT … FOR UPDATE`).
- Numeración correlativa: `VEN-000001`, `DES-000001`. Lotes PT: `PT-<código>-<AAMMDD>-<orden>`.

## Archivos nuevos y modificados

**Nuevos:** `app/utils.py`; los modelos `produccion`, `producto_terminado`, `cliente`, `venta` y `dashboard`;
los controladores `producto_terminado`, `cliente` y `venta`; las plantillas `productos_terminados/`, `clientes/`,
`ventas/` y `errores/`; la carpeta `static/vendor/`; la carpeta `database/`.

**Modificados:** `app/__init__.py`, `orden_produccion_controller.py`, `orden_produccion_model.py`,
`base.html`, `dashboard.html`, `auth/login.html`, `ordenes_produccion/listar.html` y `detalle.html`, `estilos.css`.
Los demás módulos (proveedores, materias primas, recepciones, recetas…) no se tocaron y heredan el nuevo diseño.
